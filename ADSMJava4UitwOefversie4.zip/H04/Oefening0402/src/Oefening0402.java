// Oefening 0402
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;  
   
public class Oefening0402 extends JFrame {
  public static void main( String args[] ) {
    JFrame frame = new Oefening0402();
    frame.setSize( 400, 300 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Oefening 0402" );
    frame.setContentPane( new Gemiddeldepaneel() );
    frame.setVisible( true );
  }
}

// Het paneel 
class Gemiddeldepaneel extends JPanel {
  private JTextField invoerVak1, invoerVak2, uitvoerVak;
  private JLabel invoerLabel1, invoerLabel2, uitvoerLabel;
  private JButton knop;
  
  public Gemiddeldepaneel() {
    // Schakel lay-outmanager uit
    setLayout( null ); 
    
    // Maak de tekstvakken
    invoerVak1 = new JTextField( 10 );
    invoerVak1.setHorizontalAlignment( JTextField.RIGHT );

    invoerVak2 = new JTextField( 10 );
    invoerVak2.setHorizontalAlignment( JTextField.RIGHT );

    uitvoerVak = new JTextField( 10 );
    uitvoerVak.setHorizontalAlignment( JTextField.RIGHT );
    uitvoerVak.setBackground( Color.YELLOW );
    // Schakel wijzigen door gebruiker in tekstvak uit
    uitvoerVak.setEditable( false );
    
    // Maak de labels
    invoerLabel1 = new JLabel( "Getal 1" );
    invoerLabel2 = new JLabel( "Getal 1" );
    uitvoerLabel = new JLabel( "Gemiddelde" );
    
    // Maak de knop
    knop = new JButton( "Bereken" );
    knop.addActionListener( new KnopHandler() );
    
    // Bepaal van alle componenten de plaats en afmeting
    invoerLabel1.setBounds( 80, 50, 120, 20 );
    invoerVak1.setBounds( 200, 50, 90, 20 );

    invoerLabel2.setBounds( 80, 80, 120, 20 );
    invoerVak2.setBounds( 200, 80, 90, 20 );
    
    knop.setBounds( 200, 110, 100, 20 );

    uitvoerLabel.setBounds( 80, 140, 120, 20 );
    uitvoerVak.setBounds( 200, 140, 90, 20 );
    
    
    // Voeg de componenten toe aan het paneel
    add( invoerLabel1);
    add( invoerVak1 );
    add( invoerLabel2);
    add( invoerVak2 );
    add( knop );
    add( uitvoerLabel );
    add( uitvoerVak );
  }

  class KnopHandler implements ActionListener {
    public void actionPerformed( ActionEvent e ) {
      String invoer = invoerVak1.getText();
      double getal1 = Double.parseDouble( invoer );

      invoer = invoerVak2.getText();
      double getal2 = Double.parseDouble( invoer );
      
      double gemiddelde = (getal1 + getal2) / 2;
      uitvoerVak.setText( "" + gemiddelde );
    }
  }
}
