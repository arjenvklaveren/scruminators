// Oefening 0403
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;  
import java.util.*;         // voor Locale
   
public class Oefening0403 extends JFrame {
  public static void main( String args[] ) {
    JFrame frame = new Oefening0403();
    frame.setSize( 400, 300 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Oefening 0403" );
    frame.setContentPane( new Paneel() );
    frame.setVisible( true );
  }
}

// Het paneel 
class Paneel extends JPanel {
  private JTextField tekstvak;
  private JLabel label;
  private JButton knop;
  
  public Paneel() {
  	// Schakel lay-outmanager uit
    setLayout( null ); 
    
    // Maak het tekstvak
    tekstvak = new JTextField( 10 );
    tekstvak.setHorizontalAlignment( JTextField.RIGHT );

    // Maak het label
    label = new JLabel( "Bevolking" );
    
    // Maak de knop
    knop = new JButton( "Bereken" );
    knop.addActionListener( new KnopHandler() );
    
    // Bepaal van alle componenten de plaats en afmeting
    label.setBounds( 30, 50, 80, 20 );
    tekstvak.setBounds( 110, 50, 100, 20 );

    knop.setBounds( 230, 50, 100, 20 );

    // Voeg de componenten toe aan het paneel
    add( label);
    add( tekstvak );
    add( knop );
  }

  class KnopHandler implements ActionListener {
    public void actionPerformed( ActionEvent e ) {
      String invoer = tekstvak.getText();
      double bevolking = Double.parseDouble( invoer );

      double bevolkingNaEenJaar = bevolking * 1.02;
      // Zorg dat er een decimale punt in de uitvoer komt ipv een komma: gebruik Locale.US
      tekstvak.setText( String.format( Locale.US, "%.1f", bevolkingNaEenJaar ) );
    }
  }
}
