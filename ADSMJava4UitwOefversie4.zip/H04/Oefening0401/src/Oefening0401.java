// Oefening 0401
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;  
   
public class Oefening0401 extends JFrame {
  public static void main( String args[] ) {
    JFrame frame = new Oefening0401();
    frame.setSize( 500, 200 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Oefening 0401" );
    frame.setContentPane( new Salarispaneel() );
    frame.setVisible( true );
  }
}

// Het paneel 
class Salarispaneel extends JPanel {
  private JTextField invoerVak, uitvoerVak;
  private JLabel invoerLabel, uitvoerLabel;
  private JButton knop;
  
  public Salarispaneel() {
    // Schakel lay-outmanager uit
    setLayout( null ); 
    
    // Maak de tekstvakken
    invoerVak = new JTextField( 10 );
    invoerVak.setHorizontalAlignment( JTextField.RIGHT );

    uitvoerVak = new JTextField( 10 );
    uitvoerVak.setHorizontalAlignment( JTextField.RIGHT );
    uitvoerVak.setBackground( Color.YELLOW );
    // Schakel wijzigen door gebruiker in tekstvak uit
    uitvoerVak.setEditable( false );
    
    // Maak de labels
    invoerLabel = new JLabel( "Maandsalaris" );
    uitvoerLabel = new JLabel( "Jaarsalaris" );
    
    // Maak de knop
    knop = new JButton( "Bereken" );
    knop.addActionListener( new KnopHandler() );
    
    // Bepaal van alle componenten de plaats en afmeting
    invoerLabel.setBounds( 80, 50, 120, 20 );
    invoerVak.setBounds( 200, 50, 90, 20 );
    
    uitvoerLabel.setBounds( 80, 80, 120, 20 );
    uitvoerVak.setBounds( 200, 80, 90, 20 );
    
    knop.setBounds( 300, 50, 100, 20 );
    
    // Voeg de componenten toe aan het paneel
    add( invoerLabel);
    add( invoerVak );
    add( uitvoerLabel );
    add( uitvoerVak );
    add( knop );
  }

  class KnopHandler implements ActionListener {
    public void actionPerformed( ActionEvent e ) {
      String invoer = invoerVak.getText();
      double maandsalaris = Double.parseDouble( invoer );

      double jaarsalaris = 12 * maandsalaris;
      // Formatteer de uitvoer
      uitvoerVak.setText( String.format( "%.2f", jaarsalaris ) );
    }
  }
}
