// Oefening 0602
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
   
public class Oefening0602 extends JFrame {
  public static void main( String args[] ) {
    JFrame frame = new Oefening0602();
    frame.setSize( 650, 200 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Oefening 0602" );
    frame.setContentPane( new Paneel() );
    frame.setVisible( true );
  }
}


// Het paneel
class Paneel extends JPanel {
  private JLabel label1, label2;
  private JTextField invoerVak1, invoerVak2;
  private Datum datum1, datum2;
  
  public Paneel() {
    setBackground( Color.WHITE );
    
    // Maak instanties van Datum
    datum1 = new Datum();
    datum2 = new Datum();

    // Doe de rest
    label1 = new JLabel( "Voer dag in" );
    invoerVak1 = new JTextField( 5 );
    invoerVak1.addActionListener( new Datum1Handler() );
    
    label2 = new JLabel( "Voer dag in" );
    invoerVak2 = new JTextField( 5 );
    invoerVak2.addActionListener( new Datum2Handler() );

    add( label1 );
    add( invoerVak1 );
    add( label2 );
    add( invoerVak2 );
  }
  
  public void paintComponent( Graphics g ) {
    super.paintComponent( g );
    g.drawString( String.format( "De eerste datum is %02d-", datum1.getDag() ) + 
                  String.format( "%02d-", datum1.getMaand() ) + 
                  String.format( "%04d", datum1.getJaar() ), 50, 100 );

    g.drawString( String.format( "De tweede datum is %02d-", datum2.getDag() ) + 
                  String.format( "%02d-", datum2.getMaand() ) + 
                  String.format( "%04d", datum2.getJaar() ), 50, 140 );

  }
  

  class Datum1Handler implements ActionListener {
    private boolean dagIngevoerd, maandIngevoerd;

    public void actionPerformed( ActionEvent e ) {
      String invoer = invoerVak1.getText();
      int getal = Integer.parseInt( invoer );

      invoerVak1.setText( "" );
      if( !dagIngevoerd ) {
        datum1.setDag( getal );
        dagIngevoerd = true;
        label1.setText( "Voer maand in" );
      }
      else
      if( !maandIngevoerd ) {
        datum1.setMaand( getal );
        maandIngevoerd = true;
        label1.setText( "Voer jaar in" );
      }
      else {
        datum1.setJaar( getal );
        // Geef de mogelijkheid tot invoer nieuwe datum
        label1.setText( "Voer dag in" );
        dagIngevoerd = false;
        maandIngevoerd = false;
        repaint();
      }
    }
  }
  

  class Datum2Handler implements ActionListener {
    private boolean dagIngevoerd, maandIngevoerd;

    public void actionPerformed( ActionEvent e ) {
      String invoer = invoerVak2.getText();
      int getal = Integer.parseInt( invoer );

      invoerVak2.setText( "" );
      if( !dagIngevoerd ) {
        datum2.setDag( getal );
        dagIngevoerd = true;
        label2.setText( "Voer maand in" );
      }
      else
      if( !maandIngevoerd ) {
        datum2.setMaand( getal );
        maandIngevoerd = true;
        label2.setText( "Voer jaar in" );
      }
      else {
        datum2.setJaar( getal );
        // Geef de mogelijkheid tot invoer nieuwe datum
        label2.setText( "Voer dag in" );
        dagIngevoerd = false;
        maandIngevoerd = false;
        repaint();
      }
    }
  }
  
  
}

 class Datum {
  // Attributen
  private int dag;
  private int maand;
  private int jaar;
  
 
  // Getters
  public int getDag() {
    return dag;
  }

  public int getMaand() {
    return maand;
  }

  public int getJaar() {
    return jaar;
  }
    
  // Setters
  public void setDag( int dag ) {
    this.dag = dag;
  }

  public void setMaand( int maand ) {
    this.maand = maand;
  }

  public void setJaar( int jaar ) {
    this.jaar = jaar;
  }
}
