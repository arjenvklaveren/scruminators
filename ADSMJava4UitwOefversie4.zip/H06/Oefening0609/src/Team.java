public class Team {
  private Leerling lid1;
  private Leerling lid2;

  public Team( Leerling lid1, Leerling lid2 ) {
    this.lid1 = lid1;
    this.lid2 = lid2;
  }
  
  public String toString() {
  	return "Team: " + lid1.toString() + " en " + lid2.toString();
  }
}
