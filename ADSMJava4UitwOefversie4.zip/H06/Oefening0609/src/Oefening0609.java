// Oefening 0609
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
   
public class Oefening0609 extends JFrame {
  public static void main( String args[] ) {
    JFrame frame = new Oefening0609();
    frame.setSize( 650, 120 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Oefening 0609" );
    frame.setContentPane( new Paneel() );
    frame.setVisible( true );
  }
}

// Het paneel
class Paneel extends JPanel {
  private JLabel invoerlabel;
  private int aantal = 0;
  private JLabel naamlabel, klaslabel, geslachtlabel, nummerlabel;
  private JTextField naamvak, klasvak, geslachtvak, nummervak;
  private JButton knop;
  
  private String uitvoerstring;
  private Leerling lid1, lid2;
  private Team team;
  
      
  public Paneel() {
    setBackground( Color.WHITE );
    uitvoerstring = "";
    
    // De componenten
    invoerlabel = new JLabel( "Voer eerste leerling in: " );

    naamlabel = new JLabel( "naam" );
    klaslabel = new JLabel( "klas" );
    geslachtlabel = new JLabel( "geslacht" );
    nummerlabel = new JLabel( "nummer" );


    naamvak = new JTextField( 10 );
    klasvak = new JTextField( 2 );
    geslachtvak = new JTextField( 2 );
    nummervak = new JTextField( 4 );
    
    knop = new JButton( "Klaar" );
    knop.addActionListener( new KnopHandler() );
    
    add( invoerlabel ); 
    
    add( naamlabel ); add( naamvak );
    add( klaslabel ); add( klasvak );
    add( geslachtlabel ); add( geslachtvak );
    add( nummerlabel ); add( nummervak );
    
    add( knop );
  }
  
  public void paintComponent( Graphics g ) {
  	super.paintComponent( g );
  	g.drawString( uitvoerstring, 100, 60 );
  }
  
  
  class KnopHandler implements ActionListener {
    public void actionPerformed( ActionEvent e ) {
      aantal++;
      if( aantal == 1 ) {
        lid1 = new Leerling( naamvak.getText(), klasvak.getText(), geslachtvak.getText(), Integer.parseInt( nummervak.getText() ) );
        invoerlabel.setText( "Voer tweede leerling in: " );
        naamvak.setText( "" );
        klasvak.setText( "" );
        geslachtvak.setText( "" );
        nummervak.setText( "" );
      }  
      else
      if( aantal == 2 ) {
        lid2 = new Leerling( naamvak.getText(), klasvak.getText(), geslachtvak.getText(), Integer.parseInt( nummervak.getText() ) );
      	team = new Team( lid1, lid2 );
      	uitvoerstring = team.toString();
    	repaint();
      }
      else
      if( aantal > 2 ){
      	uitvoerstring = "Je hebt al twee teamleden ingevoerd";
      	repaint();
      }	
    }
  }
}
