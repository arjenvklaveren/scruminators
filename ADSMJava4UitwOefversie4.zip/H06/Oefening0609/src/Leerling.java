public class Leerling {
  // Attributen
  private String naam;
  private String klas;
  private String geslacht;
  private int nummer;
  
  // Constructor
  public Leerling( String nm, String kl, 
                   String gesl, int nr ) {
    naam = nm;
    klas = kl;
    geslacht = gesl;
    nummer = nr;
  }
  
  // Methoden
  public String getNaam() {
    return naam;
  }

  public String getKlas() {
    return klas;
  }

  public String getGeslacht() {
    return geslacht;
  }

  public int getNummer() {
    return nummer;
  }
  
  public String toString() {
  	return getNaam() + "(" + getGeslacht() + "), klas " + getKlas() + ", nr = " + getNummer();
  }
}

