// Oefening 0607
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
   
public class Oefening0607 extends JFrame {
  public static void main( String args[] ) {
    JFrame frame = new Oefening0607();
    frame.setSize( 700, 300 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Oefening 0607" );
    frame.setContentPane( new Paneel() );
    frame.setVisible( true );
  }
}

// Het paneel
class Paneel extends JPanel {
  private Cirkel cirkel;
  private JButton knop;
  private JTextField straalVak, xVak, yVak;
      
  public Paneel() {
    setBackground( Color.WHITE );
    
    // Maak een instantie van Cirkel
    cirkel = new Cirkel( 100 );
    
    // De componenten
    knop = new JButton( "Teken" );
    knop.addActionListener( new KnopHandler() );
    
    straalVak = new JTextField( 10 );
    xVak = new JTextField( 10 );
    yVak = new JTextField( 10 );
    
    add( new JLabel( "straal" ) );
    add( straalVak );
    add( new JLabel( "xM" ) );
    add( xVak );
    add( new JLabel( "yM" ) );
    add( yVak );
    add( knop );
  }
  
  public void paintComponent( Graphics g ) {
    super.paintComponent( g );
    cirkel.teken( g );
  }
  
  class KnopHandler implements ActionListener {
    public void actionPerformed( ActionEvent e ) {
      String invoer = straalVak.getText();
      if( !invoer.equals( "" ) ) {
      	int straal = Integer.parseInt( invoer );
      	cirkel.setStraal( straal );
      }
    
      String invoer1, invoer2;
      invoer1 = xVak.getText();
      invoer2 = yVak.getText();
      
      if( !invoer1.equals( "" ) && !invoer2.equals( "" ) ) {
      	int x = Integer.parseInt( invoer1 );
      	int y = Integer.parseInt( invoer2 );
      	cirkel.setMiddelpunt( x, y );
      }
      repaint();
    }
  }
}
