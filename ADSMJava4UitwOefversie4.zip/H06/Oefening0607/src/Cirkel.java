import java.awt.*;

public class Cirkel {
  // Attributen
  private int straal, xM, yM;
  
  // Constructor
  public Cirkel( int straal ) {
  	this.straal = straal;
  }
  
  // Setter
  public void setStraal( int straal ) {
    this.straal = straal;
  }

  public void setMiddelpunt( int xM, int yM ) {
  	this.xM = xM;
  	this.yM = yM;
  }
  
  // Andere methoden
  public void teken( Graphics pen ) {
  	pen.drawOval( xM - straal, yM - straal, 2 * straal, 2 * straal );
  }
}
