// Oefening 0608
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
   
public class Oefening0608 extends JFrame {
  public static void main( String args[] ) {
    JFrame frame = new Oefening0608();
    frame.setSize( 400, 500 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Oefening 0608" );
    frame.setContentPane( new Paneel() );
    frame.setVisible( true );
  }
}

// Het paneel
class Paneel extends JPanel {
  private Verkeerslicht verkeerslicht;
  private JButton knopRood, knopOranje, knopGroen;
      
  public Paneel() {
    setBackground( Color.WHITE );
    
    // Maak een instantie van verkeerslicht
    verkeerslicht = new Verkeerslicht( 200 );
    
    // De componenten
    knopRood = new JButton( "Rood" );
    knopRood.setBackground( Color.RED );
    
    knopOranje = new JButton( "Oranje" );
    knopOranje.setBackground( Color.ORANGE );

    knopGroen = new JButton( "Groen" );
    knopGroen.setBackground( Color.GREEN );
    
    KnopHandler kh = new KnopHandler();
    knopRood.addActionListener( kh );
    knopOranje.addActionListener( kh );
    knopGroen.addActionListener( kh );
    
    add( knopRood );
    add( knopOranje );
    add( knopGroen );
  }
  
  public void paintComponent( Graphics g ) {
    super.paintComponent( g );
    verkeerslicht.teken( g );
  }
  
  class KnopHandler implements ActionListener {
    public void actionPerformed( ActionEvent e ) {
      if( e.getSource() == knopRood ) {
      	verkeerslicht.setRood();
      }
      else
      if( e.getSource() == knopOranje ) {
      	verkeerslicht.setOranje();
      }
      else
      if( e.getSource() == knopGroen ) {
      	verkeerslicht.setGroen();
      }
      repaint();
    }
  }
}
