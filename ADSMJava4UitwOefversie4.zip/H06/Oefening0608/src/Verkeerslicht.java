import java.awt.*;

class Verkeerslicht {
  private boolean rood, oranje, groen;
  private int positie;

  public Verkeerslicht( int positie ) {
    this.positie = positie;
    rood = true;
    oranje = true;
    groen = true;
  }    
    
  public void reset() {
    rood   = false;
    oranje = false;
    groen  = false;
  }

  public void setRood() {
    reset();
    rood = true;
  }

  public void setOranje() {
    reset();
    oranje = true;
  }

  public void setGroen() {
    reset();
    groen = true;
  }

  public void teken( Graphics pen ) {
    pen.setColor( Color.BLACK );
    // Bovenkant van verkeerslicht
    pen.fillRect( positie - 30, 50, 60, 160 ); 
    // De paal
    pen.fillRect( positie - 5, 210, 10, 120 );
    
    // Teken de drie lampen in lichtgrijs
    pen.setColor( Color.LIGHT_GRAY );
    pen.fillOval( positie - 20, 60, 40, 40 );
    pen.fillOval( positie - 20, 110, 40, 40 );
    pen.fillOval( positie - 20, 160, 40, 40 );

    
    // Ga na welke lamp aan moet
    if( rood ) {           
      pen.setColor( Color.RED );
      pen.fillOval( positie - 20, 60, 40, 40 );
    }
    if( oranje ) {
      pen.setColor( Color.ORANGE );
      pen.fillOval( positie - 20, 110, 40, 40 );
    }
    if( groen ) {
      pen.setColor( Color.GREEN );
      pen.fillOval( positie - 20, 160, 40, 40 );
    }
  }
}
