// Oefening 0601
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
   
public class Oefening0601 extends JFrame {
  public static void main( String args[] ) {
    JFrame frame = new Oefening0601();
    frame.setSize( 320, 180 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Oefening 0601 " );
    frame.setContentPane( new Paneel() );
    frame.setVisible( true );
  }
}


// Het paneel
class Paneel extends JPanel {
  private JLabel label;
  private JTextField invoerVak;
  private Datum datum;
  
  public Paneel() {
    setBackground( Color.WHITE );
    
    // Maak een instantie van Datum
    datum = new Datum();

    label = new JLabel( "Voer dag in" );
    invoerVak = new JTextField( 5 );
    invoerVak.addActionListener( new InvoerVakHandler() );
    
    add( label );
    add( invoerVak );
  }
  
  public void paintComponent( Graphics g ) {
    super.paintComponent( g );
    g.drawString( String.format( "De ingevoerde datum is %02d-", datum.getDag() ) + 
                  String.format( "%02d-", datum.getMaand() ) + 
                  String.format( "%04d", datum.getJaar() ), 50, 100 );
  }
  



  class InvoerVakHandler implements ActionListener {
    private boolean dagIngevoerd, maandIngevoerd;   // worden automatisch met false geinitialiseerd

    public void actionPerformed( ActionEvent e ) {
      String invoer = invoerVak.getText();
      int getal = Integer.parseInt( invoer );
      
      invoerVak.setText( "" );
      if( !dagIngevoerd ) {
        datum.setDag( getal );
        dagIngevoerd = true;
        label.setText( "Voer maand in" );
      }
      else
      if( !maandIngevoerd ) {
        datum.setMaand( getal );
        maandIngevoerd = true;
        label.setText( "Voer jaar in" );
      }
      else {
        datum.setJaar( getal );
        // Geef de mogelijkheid tot invoer nieuwe datum
        label.setText( "Voer dag in" );
        dagIngevoerd = false;
        maandIngevoerd = false;
        repaint();
      }
    }
  }
}

 class Datum {
  // Attributen
  private int dag;
  private int maand;
  private int jaar;
  
 
  // Getters
  public int getDag() {
    return dag;
  }

  public int getMaand() {
    return maand;
  }

  public int getJaar() {
    return jaar;
  }
    
  // Setters
  public void setDag( int dag ) {
    this.dag = dag;
  }

  public void setMaand( int maand ) {
    this.maand = maand;
  }

  public void setJaar( int jaar ) {
    this.jaar = jaar;
  }
}
