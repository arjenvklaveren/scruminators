// Oefening 0603
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

   
public class Oefening0603 extends JFrame {
  public static void main( String args[] ) {
    JFrame frame = new Oefening0603();
    frame.setSize( 500, 160 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Oefening 0603" );
    frame.setContentPane( new Paneel() );
    frame.setVisible( true );
  }
}

// Het paneel
class Paneel extends JPanel {
  private Tijdstip tijdstip;
  
  public Paneel() {
    setBackground( Color.WHITE );
    
    // Maak een instantie van Tijdstip
    tijdstip = new Tijdstip();
    
    // Vraag de systeemtijd op
    Calendar nu = Calendar.getInstance();
    
    int uur = nu.get( Calendar.HOUR_OF_DAY );  // 24-uursklok, Calendar.HOUR levert 12-uursklok
    int minuut = nu.get( Calendar.MINUTE );
    int seconde = nu.get( Calendar.SECOND );
    
    //Kopieer de waarden van de systeemtijd in de tijdstip-instantie
    tijdstip.setUur( uur );
    tijdstip.setMinuut( minuut );
    tijdstip.setSeconde( seconde );
  }
  
  public void paintComponent( Graphics g ) {
    super.paintComponent( g );
    g.drawString( String.format( "Vlak voor je dit las was het %02d uur %02d minuten en %02d seconden", 
   	                 tijdstip.getUur(), tijdstip.getMinuut(), tijdstip.getSeconde() ), 50, 50 );

  }
}

 class Tijdstip {
  // Attributen
  private int uur;
  private int minuut;
  private int seconde;
  
 
  // Getters
  public int getUur() {
    return uur;
  }

  public int getMinuut() {
    return minuut;
  }

  public int getSeconde() {
    return seconde;
  }
    
  // Setters
  public void setUur( int uur ) {
    this.uur = uur;
  }

  public void setMinuut( int minuut ) {
    this.minuut = minuut;
  }

  public void setSeconde( int seconde ) {
    this.seconde = seconde;
  }
}
