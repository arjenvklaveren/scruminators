public class Bankrekening {
  // Attributen
  private String rekeningnummer;
  private double saldo;
  
  // Methoden
  public double getSaldo() {
    return saldo;
  }
  
  public void stort( double bedrag ) {
    saldo += bedrag;
  }
  
  public double neemOp( double bedrag ) {
    saldo -= bedrag;
    return bedrag;
  }
}
