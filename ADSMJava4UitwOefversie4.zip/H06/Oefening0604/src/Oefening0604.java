// Oefening 0604
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
   
public class Oefening0604 extends JFrame {
  public static void main( String args[] ) {
    JFrame frame = new Oefening0604();
    frame.setSize( 400, 180 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Oefening 0604" );
    frame.setContentPane( new Paneel() );
    frame.setVisible( true );
  }
}


// Het paneel
class Paneel extends JPanel {
  private JLabel label;
  private JTextField invoerVak;
  private JButton opneemKnop, stortKnop;
  private Bankrekening rekening;
  
  public Paneel() {
    setBackground( Color.WHITE );
    
    // Maak een instantie van Bankrekening
    rekening = new Bankrekening();

    // Maak de rest
    label = new JLabel( "Voer bedrag in" );
    invoerVak = new JTextField( 10 );
    
    stortKnop = new JButton( "Storten");
    opneemKnop = new JButton( "Opnemen");
    stortKnop.addActionListener( new StortKnopHandler() );
    opneemKnop.addActionListener( new OpneemKnopHandler() );

    add( label );
    add( invoerVak );
    add( stortKnop);
    add( opneemKnop );
  }
  
  public void paintComponent( Graphics g ) {
    super.paintComponent( g );
    g.drawString( String.format( "Saldo: %8.2f Euro", rekening.getSaldo() ), 50, 100 );
  }
  
  class StortKnopHandler implements ActionListener {
    public void actionPerformed( ActionEvent e ) {
      String invoer = invoerVak.getText();
      double bedrag = Double.parseDouble( invoer );
      
      invoerVak.setText( "" );
      rekening.stort( bedrag );
      repaint();
    }
  }

  class OpneemKnopHandler implements ActionListener {
    public void actionPerformed( ActionEvent e ) {
      String invoer = invoerVak.getText();
      double bedrag = Double.parseDouble( invoer );
      
      invoerVak.setText( "" );
      rekening.neemOp( bedrag );
      repaint();
    }
  }
}
