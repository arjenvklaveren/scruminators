// Oefening 0801
public class Oefening0801 {
  public static void main( String[] args ) {
    Voorraad voorraad = new Voorraad();
    Item item1 = new Boek( "Java", 39.90, 9 );
    Item item2 = new Tijdschrift( "Viva", 2.15, 24, 3 );
    Item item3 = new Tijdschrift( "Top Gear Magazine", 5.95, 15, 2 );
    
    System.out.println( "Voor verkoop" );
    voorraad.voegtoe( item1 );
    voorraad.voegtoe( item2 );
    voorraad.voegtoe( item3 );
    voorraad.print();
    
    System.out.println( "\nNa verkoop" );
    voorraad.verkoop( "Java" );
    voorraad.verkoop( "Top Gear Magazine" );
    voorraad.verkoop( "Top Gear Magazine" );
    voorraad.print();
  }
}
