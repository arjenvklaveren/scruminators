public class Boek extends Item {
  public Boek( String titel, double prijs, int aantal ) {
    super( titel, prijs, aantal );
  }
}
