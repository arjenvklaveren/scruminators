public class CD extends AbstractItem {
  private String artiest;
  
  public CD( String titel, String artiest, double prijs, int aantal ) {
    super( titel, prijs, aantal );
    this.artiest = artiest;  
  }
  
  public String toString() {
    return String.format( "%-20s %5.2f %3d stuks (%s)", getTitel(), getPrijs(), getAantal(), artiest );
  }
}
