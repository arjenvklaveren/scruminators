public class Tijdschrift extends AbstractItem {
  private int weeknr;
  
  public Tijdschrift( String titel, double prijs, int aantal, int weeknr ) {
    super( titel, prijs, aantal );
    this.weeknr = weeknr;
  }
  
  public int getWeeknr() {
    return weeknr;
  }
  
  public String toString() {
    return String.format( "%-20s %5.2f %3d stuks, weeknr %d", getTitel(), getPrijs(), getAantal(), getWeeknr() );
  }
}
