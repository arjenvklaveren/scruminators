
/**
 * Interface voor items in een boekhandel
 * 
 * @author Gertjan Laan 
 * @version 2.0
 */
public interface Item {
  public String getTitel();
  public double getPrijs();
  public int getAantal();
  public String toString();
  public void verminderAantal( int hoeveelheid );
}
