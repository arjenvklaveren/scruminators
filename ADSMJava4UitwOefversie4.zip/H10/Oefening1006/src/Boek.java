public class Boek extends AbstractItem {
  public Boek( String titel, double prijs, int aantal ) {
    super( titel, prijs, aantal );
  }
  
  public String toString() {
    return String.format( "%-20s %5.2f %3d stuks", getTitel(), getPrijs(), getAantal() );
  }
}
