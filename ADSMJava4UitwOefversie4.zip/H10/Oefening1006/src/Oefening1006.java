/**
 * @(#)Oefening1006.java
 *
 * Oefening1006 application
 *
 * @author Gertjan Laan
 * @version 1.00 2013/11/6
 */
 
public class Oefening1006 {
  public static void main(String[] args) {
    Voorraad voorraad = new Voorraad();
    
    voorraad.voegtoe( new CD("Enigma", "Elgar", 17.5, 2) );
    voorraad.voegtoe( new Tijdschrift("Maarten", 7, 3, 34) );
    voorraad.voegtoe( new Tijdschrift("Linda", 8, 5, 34) );
    voorraad.voegtoe( new Boek("Het laatste oordeel", 22.5, 2) );

    voorraad.print();
  }
}
