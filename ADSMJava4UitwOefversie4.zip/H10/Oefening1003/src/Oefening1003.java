/**
 * @(#)Oefening1003.java
 *
 * Oefening1003 application
 *
 * @author 
 * @version 1.00 2013/11/6
 */
 
public class Oefening1003 {
  public static void main(String[] args) {
      
    Huisdier kat = new Kat( "Tom" );
    Huisdier hond = new Hond( "Tarzan" );
      
    kat.maakGeluid();
    hond.maakGeluid();
  }
}
