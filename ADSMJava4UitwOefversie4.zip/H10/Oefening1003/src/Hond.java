public class Hond extends Huisdier {
  public Hond( String naam ) {
    super( naam );
  }
  
  public void maakGeluid() {
    System.out.println( "Woef!" );
  }
}
