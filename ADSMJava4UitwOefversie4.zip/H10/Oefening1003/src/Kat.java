public class Kat extends Huisdier {
  public Kat( String naam ) {
    super( naam );
  }
  
  public void maakGeluid() {
    System.out.println( "Miauw" );
  }
}
