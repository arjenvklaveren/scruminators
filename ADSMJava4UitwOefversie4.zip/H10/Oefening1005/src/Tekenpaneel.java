import java.awt.*;
import javax.swing.*;
import java.util.*;

class Tekenpaneel extends JPanel {
  private Auto auto;
  
  public Tekenpaneel() {
    auto = new Auto( 20, 150, 80, 30 );
  }
  
  public void paintComponent( Graphics g ) {
    super.paintComponent( g );
    setBackground( Color.WHITE );     
    auto.teken( g );
  }
}
	