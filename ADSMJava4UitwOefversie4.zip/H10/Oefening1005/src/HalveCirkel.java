import java.awt.*;

public class HalveCirkel extends AbstractOnderdeel {
  private int diameter, starthoek;

  public HalveCirkel( Color kleur, int links, int onder, 
                      int diameter, int starthoek ) {
    super( kleur, links, onder );
    this.diameter = diameter;
    this. starthoek = starthoek;
  }

  // implementatie van abstracte methode
  public void teken( Graphics g ) { 
    g.setColor( kleur ) ;
    g.fillArc( links, onder-diameter, diameter, diameter, starthoek, 180 );
    g.setColor( Color.black );
    g.drawArc( links, onder-diameter, diameter, diameter, starthoek, 180 );
  }
}
  