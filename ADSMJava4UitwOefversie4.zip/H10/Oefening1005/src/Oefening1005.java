/**
 * @(#)Oefening1005.java
 *
 * Oefening1005 application
 *
 * @author Gertjan Laan
 * @version 1.00 2013/11/6
 */
 
import javax.swing.*;
   
// Opstartklasse  
public class Oefening1005 extends JFrame {
  public static void main( String args[] ) {
    JFrame frame = new Oefening1005();
    frame.setSize( 400, 200 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Oefening 1005" );
    frame.setContentPane( new Tekenpaneel() );
    frame.setVisible( true );
  }
}