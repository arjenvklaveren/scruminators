import java.awt.*;

public class Driehoek extends AbstractOnderdeel {
  private int diameter;
  private Polygon driehoek;

  public Driehoek( Color kleur, int xA, int yA, int xB, int yB, int xC, int yC ) {
    this.kleur = kleur;
    int[] xDriehoek = { xA, xB, xC };
    int[] yDriehoek = { yA, yB, yC };
    driehoek = new Polygon( xDriehoek, yDriehoek, 3 );
  }

  // implementatie van abstracte methode
  public void teken( Graphics g ) { 
    g.setColor( kleur ) ;
    g.fillPolygon( driehoek );
    g.setColor( Color.BLACK );
    g.drawPolygon( driehoek );
  }
}
