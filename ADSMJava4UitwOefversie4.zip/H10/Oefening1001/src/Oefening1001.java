/**
 * @(#)Oefening1001.java
 *
 * Oefening1001 application
 *
 * @author Gertjan Laan
 * @version 1.00 2013/11/6
 */
 
public class Oefening1001 {
    public static void main(String[] args) {
    	
    	Kat kat = new Kat( "Tom" );
    	Hond hond = new Hond( "Tarzan" );
    	
    	kat.maakGeluid();
    	hond.maakGeluid();
    }
}
