/**
 * @(#)Oefening1002.java
 *
 * Oefening1002 application
 *
 * @author Gertjan Laan
 * @version 1.00 2013/11/6
 */
 
public class Oefening1002 {
  public static void main(String[] args) {
    	
    Huisdier kat = new Kat( "Tom" );
    Huisdier hond = new Hond( "Tarzan" );
    	
    kat.maakGeluid();
    hond.maakGeluid();
  }
}
