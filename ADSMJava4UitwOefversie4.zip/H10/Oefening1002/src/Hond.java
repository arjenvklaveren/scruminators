public class Hond extends Huisdier {
  public Hond( String naam ) {
    super( naam );
  }
}
