public class Kat extends Huisdier {
  public Kat( String naam ) {
    super( naam );
  }
}
