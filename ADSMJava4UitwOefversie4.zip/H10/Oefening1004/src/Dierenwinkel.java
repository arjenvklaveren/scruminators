import java.util.*;

public class Dierenwinkel {
  private ArrayList<Huisdier> lijst;
  
  public Dierenwinkel() {
    lijst = new ArrayList<Huisdier>();
  }
  
  public void voegToe( Huisdier dier ) {
    lijst.add( dier );
  }
  
  public void printOverzicht() {
    System.out.println( "In de winkel zijn aanwezig:" );
    for( Huisdier d : lijst ) 
      System.out.println( d );
  }
}
