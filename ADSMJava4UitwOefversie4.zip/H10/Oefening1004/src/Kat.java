public class Kat extends Huisdier {
  public Kat( String naam ) {
    super( naam );
  }
  
  @Override
  public void maakGeluid() {
    System.out.println( "Miauw" );
  }
  
  public String toString() {
    return "kat " + naam;
  }

}
