/**
 * @(#)Oefening1004.java
 *
 * Oefening1004 application
 *
 * @author Gertjan Laan
 * @version 1.00 2013/11/6
 */
 
public class Oefening1004 {
  public static void main(String[] args) {
    Dierenwinkel winkel = new Dierenwinkel();
    winkel.voegToe( new Kat( "Felix" ) );
    winkel.voegToe( new Hond( "Epke" ) );
    winkel.voegToe( new Hamster( "Knabbel" ) );
    
    winkel.printOverzicht();
  }
}
