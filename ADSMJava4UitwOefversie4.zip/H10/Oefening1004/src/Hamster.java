public class Hamster extends Huisdier {
  public Hamster( String naam ) {
    super( naam );
  }
  
  public void maakGeluid() {
    System.out.println( "Knaag" );
  }

  public String toString() {
    return "hamster " + naam;
  }
}
