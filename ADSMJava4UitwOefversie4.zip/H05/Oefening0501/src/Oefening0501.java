// Oefening 0501 
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;  
   
public class Oefening0501 extends JFrame {
  public static void main( String args[] ) {
    JFrame frame = new Oefening0501();
    frame.setSize( 400, 200 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Oefening 0501" );
    frame.setContentPane( new Paneel() );
    frame.setVisible( true );
  }
}

// Het paneel 
class Paneel extends JPanel {
  private JTextField invoerVakLinks, invoerVakRechts;
  private String mededeling;
  	
  public Paneel() {
    // Tekst bij de start van het programma
    mededeling = "Voer twee getallen in en druk op Enter";
    
    // Maak de tekstvakken
    invoerVakLinks = new JTextField( 10 );
    invoerVakRechts = new JTextField( 10 );

    // Maak 1 handler voor beide tekstvakken
    // Als je in het tekstvak op Enter drukt wordt de handler geactiveerd
    InvoerVakHandler ivh = new InvoerVakHandler();
    invoerVakLinks.addActionListener( ivh );
    invoerVakRechts.addActionListener( ivh );

    // Voeg alles toe aan het paneel
    add( invoerVakLinks);
    add( invoerVakRechts );
  }

  public void paintComponent( Graphics g ) {
  	super.paintComponent( g );
  	g.drawString( mededeling, 100, 100 );
  }

  class InvoerVakHandler implements ActionListener {
    public void actionPerformed( ActionEvent e ) {
      double getalLinks, getalRechts;
      String invoerLinks = invoerVakLinks.getText();
      String invoerRechts = invoerVakRechts.getText();
      
      // Controleer eerst of een van beide vakken niet leeg is
      if( !invoerLinks.equals( "" ) && !invoerRechts.equals( "" ) ) {
        getalLinks = Double.parseDouble( invoerLinks );
        getalRechts = Double.parseDouble( invoerRechts );
        if( getalLinks > getalRechts )
          mededeling = "Getal links is groter dan getal rechts";
        else
        if( getalRechts > getalLinks )
          mededeling = "Getal rechts is groter dan getal links";
        else 
          mededeling = "Getallen zijn gelijk";
        repaint();	 
      }
    }
  }
}
