// Oefening 0513 Fibonacci
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
   
public class Oefening0513 extends JFrame {
  public static void main( String args[] ) {
    JFrame frame = new Oefening0513();
    frame.setSize( 600, 800 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Oefening 0513" );
    frame.setContentPane( new FibonacciPaneel() );
    frame.setVisible( true );
  }
}


class FibonacciPaneel extends JPanel {
  public FibonacciPaneel() {
    setBackground( Color.LIGHT_GRAY );
  }
 
  public void paintComponent( Graphics g ) {
    super.paintComponent( g );

    int x = 5, y = 60;       // positie van de uitvoer
    int eerste = 1, tweede = 1, som;
    g.drawString( "a. De eerste 15 getallen van Fibonacci:", x, 20 );
    g.drawString( "" + eerste + "   " + tweede, x, 40 );
    for ( int i = 3; i <= 15; i++ ) {
      som = eerste + tweede;
      g.drawString( "  " + som, x+=25, 40 );
      eerste = tweede;
      tweede = som;
    }
    
    x=5;
    g.drawString( "b. Quotient van twee opvolgende Fibonacci-getallen:", x, y );
    eerste = 1; tweede = 1; 
    for ( int i = 3; i <= 15; i++ ) {
      double quotient = (double) tweede / eerste;
      g.drawString( "" + quotient, 50, y+=20 );
      som = eerste + tweede;
      eerste = tweede;
      tweede = som;
    }


    x=5; 
    g.drawString( "c. De verhouding tussen de getallen in de rij van Fibonacci benaderen de Gulden Snedeverhouding.", x, y+=20 );

    g.drawString( "d.", x, y+=20 );
    eerste = 1; tweede = 1; 
    for ( int i = 3; i <= 100; i++ ) {
      som = eerste + tweede;
      if (som % i == 0 ) {
        g.drawString( "Het " + i + "de getal, " + som + ", is deelbaar door " + i, x, y+=20 );
      }
      eerste = tweede;
      tweede = som;
    }
    g.drawString( "Dus ja, er zijn meer van dat soort getallen.", x, y+=20 );
  }
}
