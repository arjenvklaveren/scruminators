// Oefening 0514
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
   
public class Oefening0514 extends JFrame {
  public static void main( String args[] ) {
    JFrame frame = new Oefening0514();
    frame.setSize( 400, 300 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Oefening 0514" );
    frame.setContentPane( new Paneel() );
    frame.setVisible( true );
  }
}

class Paneel extends JPanel {
  private JLabel label;
  private JTextField invoerVak;
  int aantalTreden;
  
  public Paneel() {
    setBackground( Color.WHITE );
    setFont( new Font( "Courier", Font.BOLD, 14 ) );
    label = new JLabel( "Hoeveel treden wens je?" );
    invoerVak = new JTextField( 8 );
    invoerVak.addActionListener( new InvoerVakHandler() );
    add( label );
    add( invoerVak );
  }
  
  public void paintComponent( Graphics g ) {
    super.paintComponent( g );
    int x = 100, y = 50;
    for( int i = 0; i < aantalTreden; i++ ) {
      if( i % 2 == 0 ) {
        g.setColor( Color.blue );
      }
      else {
        g.setColor( Color.red );
      }
      g.drawLine( x, y, x += 15, y );
      g.drawLine( x, y, x, y+= 15 );
    }
  }
  
  class InvoerVakHandler implements ActionListener {
    public void actionPerformed( ActionEvent e ) {
      aantalTreden = Integer.parseInt( invoerVak.getText() );
      repaint(); 
    }
  }
}
