// Oefening 0507
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
   
public class Oefening0507 extends JFrame {
  public static void main( String args[] ) {
    JFrame frame = new Oefening0507();
    frame.setSize( 300, 200 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Oefening 0507" );
    frame.setContentPane( new Paneel() );
    frame.setVisible( true );
  }
}


class Paneel extends JPanel {
  private JTextField invoerVak;
  private int aantal;
  
  public Paneel() {
    setBackground( Color.WHITE );
    invoerVak = new JTextField( 10 );
    invoerVak.addActionListener( new InvoerVakHandler() );
    
    add( new JLabel( "Voer aantal in" ) );
    add( invoerVak );
  }
  
  public void paintComponent( Graphics g ) {
    super.paintComponent( g );
    for( int i = 0; i < aantal; i++ ) {
      g.drawRect( 150 - 10*i, 90 - 10*i, 10 + 20*i, 10 + 20*i );
    }
  }
  
  class InvoerVakHandler implements ActionListener {
    public void actionPerformed( ActionEvent e ) {
      String invoer = invoerVak.getText();
      aantal = Integer.parseInt( invoer );
      repaint();
    }
  }
}

