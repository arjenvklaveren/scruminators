// Oefening 0510
import javax.swing.*;
import java.awt.*;
   
public class Oefening0510 extends JFrame {
  public static void main( String args[] ) {
    JFrame frame = new Oefening0510();
    frame.setSize( 270, 210 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Spiraal" );
    frame.setContentPane( new Paneel() );
    frame.setVisible( true );
  }
}


class Paneel extends JPanel {
 
  public Paneel() {
    setBackground( Color.WHITE );
  }
  
  public void paintComponent( Graphics g ) {
    super.paintComponent( g );
    int x = 70,
        y = 30,
        lengte = 100;

    for( int i = 1; i <= 5; i++ ) { 
      g.drawLine( x, y, x += lengte, y );
      g.drawLine( x, y, x, y += lengte );
      lengte -= 10;
      
      g.drawLine( x, y, x -=lengte, y);
      g.drawLine( x, y, x, y -= lengte );
      lengte -= 10;
    }
  }
}


