// Oefening 0506
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
   
public class Oefening0506 extends JFrame {
  public static void main( String args[] ) {
    JFrame frame = new Oefening0506();
    frame.setSize( 500, 200 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Oefening 0506" );
    frame.setContentPane( new Paneel() );
    frame.setVisible( true );
  }
}


class Paneel extends JPanel {
  private int som;
  
  public Paneel() {
    setBackground( Color.WHITE );
    som = 0;
    for( int i = 1; i <= 1000; i++ )
      som += i;
  }
  
  public void paintComponent( Graphics g ) {
    super.paintComponent( g );
    g.drawString( String.format( "De som van de getallen 1 t/m 1000 is %8d", som ), 100, 50 );
  }
}

