// Oefening 0504
// for statement
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
   
public class Oefening0504 extends JFrame {
  public static void main( String args[] ) {
    JFrame frame = new Oefening0504();
    frame.setSize( 300, 400 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Oefening 0504" );
    frame.setContentPane( new Paneel() );
    frame.setVisible( true );
  }
}


class Paneel extends JPanel {
  
  public Paneel() {
    setBackground( Color.WHITE );
  }
  
  public void paintComponent( Graphics g ) {
    super.paintComponent( g );
    for( int i = 1; i <= 10; i++ ) {
      g.drawRect( 50 - 2*i, 100 - 2*i, 20 + 10*i, 40 + 15*i );
    }
  }
}

