// Oefening 0508 
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;  
   
public class Oefening0508 extends JFrame {
  public static void main( String args[] ) {
    JFrame frame = new Oefening0508();
    frame.setSize( 500, 200 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Oefening 0508" );
    frame.setContentPane( new Paneel() );
    frame.setVisible( true );
  }
}

// Het paneel 
class Paneel extends JPanel {
  private JTextField tekstvak;
  private String mededeling;
  	
  public Paneel() {
    // Tekst bij de start van het programma
    mededeling = "Voer aantal balpennen in";
    
    // Maak het tekstvak
    tekstvak = new JTextField( 10 );
    tekstvak.addActionListener( new TekstvakHandler() );

    // Voeg toe aan het paneel
    add( tekstvak );
  }

  public void paintComponent( Graphics g ) {
  	super.paintComponent( g );
  	g.drawString( mededeling, 100, 100 );
  }

  class TekstvakHandler implements ActionListener {
    public void actionPerformed( ActionEvent e ) {
      String invoer = tekstvak.getText();
      int aantal;
      double prijsPerStuk, totaalBedrag;
      
      // Controleer eerst of het vak niet leeg is
      if( !tekstvak.equals( "" ) ) {
        aantal = Integer.parseInt( invoer );
        if( aantal < 10 )
          prijsPerStuk = 2.00;
        else   // aantal is groter dan of gelijk aan 10
        if( aantal < 50 )
          prijsPerStuk = 1.50;
        else   // aantal is groter dan of gelijk aan 50	 
        if( aantal < 100 )
          prijsPerStuk = 1.25;
        else   // aantal > 100
          prijsPerStuk = 1.10;

        totaalBedrag = aantal * prijsPerStuk;

        mededeling = 
          String.format( "%8d balpennen van %4.2f per stuk kosten %8.2f", 
          	              aantal, prijsPerStuk, totaalBedrag );
        repaint();	 
      }
    }
  }
}
