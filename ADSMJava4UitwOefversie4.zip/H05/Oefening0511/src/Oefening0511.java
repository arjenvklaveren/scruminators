// Oefening 0511
import javax.swing.*;
import java.awt.*;
   
public class Oefening0511 extends JFrame {
  public static void main( String args[] ) {
    JFrame frame = new Oefening0511();
    frame.setSize( 270, 210 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Concentrische cirkels" );
    frame.setContentPane( new Paneel() );
    frame.setVisible( true );
  }
}


class Paneel extends JPanel {
 
  public Paneel() {
    setBackground( Color.WHITE );
  }
  
  public void paintComponent( Graphics g ) {
    super.paintComponent( g );
    int x = 70,
        y = 30,
        d = 100;

    for( int i = 0; i < 5; i++ ) {
      g.drawOval( x, y, d, d );
      x += 10;
      y += 10;
      d -= 20;
    }
  }
}


