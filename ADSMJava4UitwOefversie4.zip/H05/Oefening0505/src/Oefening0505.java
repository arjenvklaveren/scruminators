// Oefening 0505
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
   
public class Oefening0505 extends JFrame {
  public static void main( String args[] ) {
    JFrame frame = new Oefening0505();
    frame.setSize( 300, 400 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Oefening 0505" );
    frame.setContentPane( new Paneel() );
    frame.setVisible( true );
  }
}


class Paneel extends JPanel {
  private double x;
  
  public Paneel() {
    setBackground( Color.WHITE );
  }
  
  public void paintComponent( Graphics g ) {
    super.paintComponent( g );
    g.setFont( new Font( "Courier", Font.BOLD, 12 ) );
    x = 10.25;
    for( int i = 1; i <= 8; i++ ) {
      g.drawString( String.format( Locale.US, "%2d %10.2f", i, x ), 100, 50 + 20 * i );
      x += 0.25;
    }
  }
}

