// Oefening 0512 Romeinse jaartallen
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
   
public class Oefening0512 extends JFrame {
  public static void main( String args[] ) {
    JFrame frame = new Oefening0512();
    frame.setSize( 600, 300 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Oefening 0512" );
    frame.setContentPane( new RomeinsPaneel() );
    frame.setVisible( true );
  }
}

class Romeins {
	public String getRomeins( int jaartal ) {
	  String romeins = "";
    if ( jaartal >= 1 && jaartal <= 2100 ) {
      while ( jaartal >= 1000 ) {
        romeins += "M";
        jaartal -= 1000;
      }
      if ( jaartal >= 900 ) {
        romeins += "CM";
        jaartal -= 900;
      }
      if ( jaartal >= 500 ) {
        romeins += "D";
        jaartal -= 500;
      }
      if ( jaartal >= 400 ) {
        romeins += "CD";
        jaartal -= 400;
      }
      while ( jaartal >= 100 ) {
        romeins += "C";
        jaartal -= 100;
      }
      if ( jaartal >= 90 ) {
        romeins += "XC";
        jaartal -= 90;
      }
      if ( jaartal >= 50 ) {
        romeins += "L";
        jaartal -= 50;
      }
      if ( jaartal >= 40 ) {
        romeins += "XL";
        jaartal -= 40;
      }
      while ( jaartal >= 10 ) {
        romeins += "X";
        jaartal -= 10;
      }
      if ( jaartal >= 9 ) {
        romeins += "IX";
        jaartal -= 9;
      }
      if ( jaartal >= 5 ) {
        romeins += "V";
        jaartal -= 5;
      }
      if ( jaartal >= 4 ) {
        romeins += "IV";
        jaartal -= 4;
      }
      while( jaartal >= 1 ) {
        romeins += "I";
        jaartal -= 1;
      }
      return romeins;
    }
    else
      return "Alleen jaartallen tussen 1 en 2100";
  }
}

class RomeinsPaneel extends JPanel {
  private JLabel label;
  private JTextField invoerVak;
  int invoer;
  Romeins rom;
  
  public RomeinsPaneel() {
    setBackground( Color.LIGHT_GRAY );
    setFont( new Font( "Courier", Font.BOLD, 14 ) );
    label = new JLabel( "Voer een jaartal in" );
    invoerVak = new JTextField( 8 );
    invoerVak.addActionListener( new InvoerVakHandler() );
    rom = new Romeins();
    
    add( label );
    add( invoerVak );
  }
 
  public void paintComponent( Graphics g ) {
    super.paintComponent( g );
    String uitvoer = rom.getRomeins( invoer );
    g.drawString( uitvoer, 290, 80 );    
  }
 
  class InvoerVakHandler implements ActionListener {
    public void actionPerformed( ActionEvent e ) {
      invoer = Integer.parseInt( invoerVak.getText() );
      repaint(); 
    }
  }
}
