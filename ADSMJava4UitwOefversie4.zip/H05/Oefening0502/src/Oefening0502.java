// Oefening 0502 
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;  
   
public class Oefening0502 extends JFrame {
  public static void main( String args[] ) {
    JFrame frame = new Oefening0502();
    frame.setSize( 500, 200 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Oefening 0502" );
    frame.setContentPane( new Paneel() );
    frame.setVisible( true );
  }
}

// Het paneel 
class Paneel extends JPanel {
  private JTextField invoerVakLinks, invoerVakMidden, invoerVakRechts;
  private String mededeling;
  	
  public Paneel() {
    // Tekst bij de start van het programma
    mededeling = "Voer drie gehele getallen in en druk op Enter";
    
    // Maak de tekstvakken
    invoerVakLinks = new JTextField( 10 );
    invoerVakMidden = new JTextField( 10 );
    invoerVakRechts = new JTextField( 10 );

    // Maak 1 handler voor de drie tekstvakken
    // Als je in een van de tekstvakken op Enter drukt wordt de handler geactiveerd
    InvoerVakHandler ivh = new InvoerVakHandler();
    invoerVakLinks.addActionListener( ivh );
    invoerVakMidden.addActionListener( ivh );
    invoerVakRechts.addActionListener( ivh );
    
    // Voeg alles toe aan het paneel
    add( invoerVakLinks);
    add( invoerVakMidden );
    add( invoerVakRechts );
  }

  public void paintComponent( Graphics g ) {
  	super.paintComponent( g );
  	g.drawString( mededeling, 150, 100 );
  }

  class InvoerVakHandler implements ActionListener {
    public void actionPerformed( ActionEvent e ) {
      int a, b, c;
      String invoerLinks = invoerVakLinks.getText();
      String invoerMidden = invoerVakMidden.getText();
      String invoerRechts = invoerVakRechts.getText();
      
      // Controleer eerst of een van de vakken niet leeg is
      if( !invoerLinks.equals( "" ) && !invoerMidden.equals( "" ) && !invoerRechts.equals( "" ) ) {
        a = Integer.parseInt( invoerLinks );
        b = Integer.parseInt( invoerMidden );
        c = Integer.parseInt( invoerRechts );
        
        // Sorteer de drie getallen van klein naar groot
        int hulp;
        if( a > b ) {
        	hulp = a; a = b; b = hulp;    // verwissel a en b
        }
        if( b > c ) {
        	hulp = b; b = c; c = hulp;    // verwissel b en c
        }
        if( a > b ) {
        	hulp = a; a = b; b = hulp;    // verwissel a en b
        }
        mededeling = "Op volgorde: " + a + ", " + b + ", " + c;
        repaint();	 
      }
    }
  }
}
