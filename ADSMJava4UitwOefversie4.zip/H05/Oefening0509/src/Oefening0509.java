// Oefening 0509 
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;  
   
public class Oefening0509 extends JFrame {
  public static void main( String args[] ) {
    JFrame frame = new Oefening0509();
    frame.setSize( 400, 200 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Oefening 0509" );
    frame.setContentPane( new Paneel() );
    frame.setVisible( true );
  }
}

// Het paneel 
class Paneel extends JPanel {
  private JTextField tekstvak;
  private String mededeling;
  	
  public Paneel() {
    // Tekst bij de start van het programma
    mededeling = "Voer een jaartal in";
    
    // Maak het tekstvak
    tekstvak = new JTextField( 10 );
    tekstvak.addActionListener( new TekstvakHandler() );

    // Voeg toe aan het paneel
    add( tekstvak );
  }

  public void paintComponent( Graphics g ) {
  	super.paintComponent( g );
  	g.drawString( mededeling, 100, 100 );
  }

  class TekstvakHandler implements ActionListener {
    public void actionPerformed( ActionEvent e ) {
      String invoer = tekstvak.getText();
      int jaartal;
      boolean isSchrikkeljaar = false;
      
      // Controleer eerst of het vak niet leeg is
      if( !tekstvak.equals( "" ) ) {
        jaartal = Integer.parseInt( invoer );
        
        if( jaartal % 4 == 0 && jaartal % 100 != 0 )
        	isSchrikkeljaar = true;
        if( jaartal % 400 == 0 )
        	isSchrikkeljaar = true;
        
        if( isSchrikkeljaar )
          mededeling = String.format( "%4d is een schrikkeljaar", jaartal );
        else 
          mededeling = String.format( "%4d is geen schrikkeljaar", jaartal );
        repaint();	 
      }
    }
  }
}
