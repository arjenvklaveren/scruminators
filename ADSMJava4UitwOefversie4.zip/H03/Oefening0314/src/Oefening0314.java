// Oefening0314
// Verkeerslicht
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
   
public class Oefening0314 extends JFrame {
  public static void main( String args[] ) {
    JFrame frame = new Oefening0314();
    frame.setSize( 400, 400 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Verkeerslicht" );
    frame.setContentPane( new Verkeerslichtpaneel() );
    frame.setVisible( true );
  }
}


class Verkeerslichtpaneel extends JPanel {
  public void paintComponent( Graphics g ) {
    super.paintComponent( g );
    g.setColor( Color.BLACK );
    g.fillRect( 170, 50, 60, 160 );
    g.fillRect( 195, 210, 10, 120 );

    g.setColor( Color.RED );
    g.fillOval( 180, 60, 40, 40 );

    g.setColor( Color.ORANGE );
    g.fillOval( 180, 110, 40, 40 );

    g.setColor( Color.GREEN );
    g.fillOval( 180, 160, 40, 40 );
  }
}
