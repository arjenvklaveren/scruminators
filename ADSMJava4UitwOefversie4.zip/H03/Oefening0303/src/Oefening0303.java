// Oefening 0303
import javax.swing.*;
import java.awt.*;  // Nodig voor Graphics
   
// Opstartklasse  
public class Oefening0303 extends JFrame {
  public static void main( String args[] ) {
    JFrame frame = new Oefening0303();
    frame.setSize( 400, 200 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Oefening 0303" );
    frame.setContentPane( new Paneel() );
    frame.setVisible( true );
  }
}

// Het paneel 
class Paneel extends JPanel {
  private int leeftijdInSeconden;
  private int aantalUur;
  private int aantalMinuten;
  private int secondenPerUur;
  
  public Paneel() {
    secondenPerUur = 60 * 60;
    leeftijdInSeconden = 5454532;
    aantalUur= leeftijdInSeconden / secondenPerUur;
    aantalMinuten = leeftijdInSeconden / 60;
  }
  
  public void paintComponent( Graphics g ) {
    super.paintComponent( g );
    g.drawString( "leeftijdInSeconden = " + leeftijdInSeconden, 40, 40 );
    g.drawString( "aantalMinuten = " + aantalMinuten, 40, 60 );
    g.drawString( "aantalUur = " + aantalUur, 40, 80 );
  }
}
