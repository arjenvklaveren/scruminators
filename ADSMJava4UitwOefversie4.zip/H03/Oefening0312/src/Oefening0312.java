// Oefening 0312
// De bewegende cirkel, die ook groter en kleiner kan worden
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
   
public class Oefening0312 extends JFrame {
  public static void main( String args[] ) {
    JFrame frame = new Oefening0312();
    frame.setSize( 290, 200 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Oefening 0312" );
    frame.setContentPane( new Cirkelpaneel() );
    frame.setVisible( true );
  }
}


class Cirkelpaneel extends JPanel {
  private JButton rechtsKnop, linksKnop, kleinerKnop, groterKnop;
  private int x;
  private int diameter;
  
  public Cirkelpaneel() {
     setBackground( Color.YELLOW );
     rechtsKnop = new JButton( "Naar rechts" );
     rechtsKnop.addActionListener( new RechtsKnopHandler() );
     linksKnop = new JButton( "Naar links" );
     linksKnop.addActionListener( new LinksKnopHandler() );
     
     kleinerKnop = new JButton( "Kleiner" );
     kleinerKnop.addActionListener( new KleinerKnopHandler() );
     groterKnop = new JButton( "Groter" );
     groterKnop.addActionListener( new GroterKnopHandler() );
     
     add( rechtsKnop );
     add( linksKnop );
     add( kleinerKnop );
     add( groterKnop );
     x = 100;
     diameter = 50;
  }

  public void paintComponent( Graphics g ) {
    super.paintComponent( g );
    // Teken met roos
    g.setColor( Color.RED );
    // Teken een cirkel
    g.fillOval( x, 80, diameter, diameter );
  }
  
  class RechtsKnopHandler implements ActionListener {
    public void actionPerformed( ActionEvent e ) {
      x++;
      repaint();
    }
  }

  class LinksKnopHandler implements ActionListener {
    public void actionPerformed( ActionEvent e ) {
      x--;
      repaint();
    }
  }

  class KleinerKnopHandler implements ActionListener {
    public void actionPerformed( ActionEvent e ) {
      diameter--;
      repaint();
    }
  }

  class GroterKnopHandler implements ActionListener {
    public void actionPerformed( ActionEvent e ) {
      diameter++;
      repaint();
    }
  }
}
