// Oefening 0305
import javax.swing.*;
import java.awt.*;  // Nodig voor Graphics
   
// Opstartklasse  
public class Oefening0305 extends JFrame {
  public static void main( String args[] ) {
    JFrame frame = new Oefening0305();
    frame.setSize( 400, 300 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Oefening 0305" );
    frame.setContentPane( new Paneel() );
    frame.setVisible( true );
  }
}

// Het paneel 
class Paneel extends JPanel {

  public Paneel() {
  	// hier hoeft niets te gebeuren
  }
  
  public void paintComponent( Graphics g ) {
    super.paintComponent( g );
    // teken de basis van de driehoek
    g.drawLine( 100, 250, 300, 250 );
    // teken een lijn van het punt links onder naar de top
    g.drawLine( 100, 250, 200, 10 );
    // teken een lijn van het punt rechts onder naar de top
    g.drawLine( 300, 250, 200, 10 );
  }
}
