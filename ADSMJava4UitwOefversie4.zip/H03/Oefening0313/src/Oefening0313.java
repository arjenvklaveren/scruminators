// Oefening 0313
// Staafdiagram

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
   
public class Oefening0313 extends JFrame {
  public static void main( String args[] ) {
    JFrame frame = new Oefening0313();
    frame.setSize( 400, 250 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Staafdiagram" );
    frame.setContentPane( new Staafdiagrampaneel() );
    frame.setVisible( true );
  }
}


class Staafdiagrampaneel extends JPanel {
  private int lengte1 = 128, lengte2 = 135, lengte3 = 105;
  	
  public Staafdiagrampaneel() {
    setBackground( Color.LIGHT_GRAY );
  }

  public void paintComponent( Graphics pen ) {
    super.paintComponent( pen );
    // Teken de staven
    pen.setColor( Color.BLUE );
    pen.fillRect( 10, 180-lengte1, 50, lengte1 );

    pen.setColor( Color.RED );
    pen.fillRect( 70, 180-lengte2, 50, lengte2 );

    pen.setColor( Color.GREEN );
    pen.fillRect( 130, 180-lengte3, 50, lengte3 );

    // Zet de namen eronder
    pen.setColor( Color.BLACK );
    pen.drawString( "Charlotte", 10, 200 );
    pen.drawString( "Welmer", 70, 200 );
    pen.drawString( "Noa", 130, 200 );
    
    // Zet de lengtes erboven
    pen.drawString( "" + lengte1, 30, 20 );
    pen.drawString( "" + lengte2, 90, 20 );
    pen.drawString( "" + lengte3, 150, 20 );
    
    
  }
 
}
