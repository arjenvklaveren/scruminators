// Oefening 0308
import javax.swing.*;
import java.awt.*;  // Nodig voor Graphics
   
// Opstartklasse  
public class Oefening0308 extends JFrame {
  public static void main( String args[] ) {
    JFrame frame = new Oefening0308();
    frame.setSize( 400, 300 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Oefening 0308" );
    frame.setContentPane( new Paneel() );
    frame.setVisible( true );
  }
}

// Het paneel 
class Paneel extends JPanel {

  public Paneel() {
  	// hier hoeft niets te gebeuren
  }
  
  public void paintComponent( Graphics g ) {
    super.paintComponent( g );
    // Je hoeft alleen de zwarte vlakjes te tekenen
    g.setColor( Color.BLACK );
    g.fillRect( 100, 50, 20, 20 );
    g.fillRect( 140, 50, 20, 20 );
    g.fillRect( 120, 70, 20, 20 );
    g.fillRect( 100, 90, 20, 20 );
    g.fillRect( 140, 90, 20, 20 );
    
    // Teken een vierkant om het geheel
    g.drawRect( 100, 50, 60, 60 );
    
  }
}
