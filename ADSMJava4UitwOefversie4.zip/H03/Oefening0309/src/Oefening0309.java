// Oefening 0309
// Optel- en vermenigvuldigingsmmachine
// Invoer van gehele getallen in een tekstvak
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class Oefening0309 extends JFrame {
  public static void main( String args[] ) {
    JFrame frame = new Oefening0309();
    frame.setSize( 400, 200 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Oefening 0309" );
    frame.setContentPane( new Optelpaneel() );
    frame.setVisible( true );
  }
}

// Paneel met drie tekstvakken
class Optelpaneel extends JPanel {
  JTextField invoervak1, invoervak2, resultaatVak;
  JButton plusKnop, maalKnop;
  
  public Optelpaneel() {
    invoervak1 = new JTextField( 10 );
    invoervak2 = new JTextField( 10 );
    resultaatVak = new JTextField( 10 );

    plusKnop = new JButton( "+" );
    plusKnop.addActionListener( new PlusKnopHandler() );
  
    maalKnop = new JButton( "x" );
    maalKnop.addActionListener( new MaalKnopHandler() );
    
    add( invoervak1 );
    add( invoervak2 );
    add( plusKnop );
    add( maalKnop );
    add( resultaatVak );
  }

  // Inwendige klassen
  class PlusKnopHandler implements ActionListener {
    public void actionPerformed( ActionEvent e ) {
      String invoerstring1 = invoervak1.getText();
      int getal1 = Integer.parseInt( invoerstring1 );

      String invoerstring2 = invoervak2.getText();
      int getal2 = Integer.parseInt( invoerstring2 );

      int resultaat = getal1 + getal2;

      resultaatVak.setText( "" + resultaat );
    }
  }  

  class MaalKnopHandler implements ActionListener {
    public void actionPerformed( ActionEvent e ) {
      String invoerstring1 = invoervak1.getText();
      int getal1 = Integer.parseInt( invoerstring1 );

      String invoerstring2 = invoervak2.getText();
      int getal2 = Integer.parseInt( invoerstring2 );

      int resultaat = getal1 * getal2;

      resultaatVak.setText( "" + resultaat );
    }
  }  


}
