// Oefening 0306
import javax.swing.*;
import java.awt.*;  // Nodig voor Graphics
   
// Opstartklasse  
public class Oefening0306 extends JFrame {
  public static void main( String args[] ) {
    JFrame frame = new Oefening0306();
    frame.setSize( 400, 300 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Oefening 0306" );
    frame.setContentPane( new Paneel() );
    frame.setVisible( true );
  }
}

// Het paneel 
class Paneel extends JPanel {

  public Paneel() {
  	// hier hoeft niets te gebeuren
  }
  
  public void paintComponent( Graphics g ) {
    super.paintComponent( g );
    // teken de onderkant van het huis
    g.drawRect( 100, 100, 100, 100 );
    // teken het dak
    g.drawLine( 100, 100, 150, 10 );
    g.drawLine( 200, 100, 150, 10 );
  }
}
