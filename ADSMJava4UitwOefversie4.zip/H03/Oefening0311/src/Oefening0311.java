// Oefening 0311
// De bewegende cirkel
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
   
public class Oefening0311 extends JFrame {
  public static void main( String args[] ) {
    JFrame frame = new Oefening0311();
    frame.setSize( 300, 200 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Oefening 0311" );
    frame.setContentPane( new Cirkelpaneel() );
    frame.setVisible( true );
  }
}


class Cirkelpaneel extends JPanel {
  private JButton rechtsKnop;
  private int x;
  
  public Cirkelpaneel() {
     setBackground( Color.YELLOW );
     rechtsKnop = new JButton( "Naar rechts" );
     rechtsKnop.addActionListener( new RechtsKnopHandler() );
     add( rechtsKnop );
     x = 100;
  }

  public void paintComponent( Graphics g ) {
    super.paintComponent( g );
    // Teken met roos
    g.setColor( Color.RED );
    // Teken een cirkel
    g.fillOval( x, 80, 50, 50 );
  }
  
  class RechtsKnopHandler implements ActionListener {
    public void actionPerformed( ActionEvent e ) {
      x++;
      repaint();
    }
  }
}
