// Oefening 0317
// Huishoudbeurs met totaal
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
   
public class Oefening0317 extends JFrame {
  public static void main( String args[] ) {
    JFrame frame = new Oefening0317();
    frame.setSize( 400, 200 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Telling huishoudbeurs, versie 2" );
    frame.setContentPane( new HuishoudbeursTotaalpaneel() );
    frame.setVisible( true );
  }
}


class HuishoudbeursTotaalpaneel extends JPanel {
  private JButton vrouwKnop, manKnop, totaalKnop;
  private int aantalVrouwen, aantalMannen, totaal;
  	
  public HuishoudbeursTotaalpaneel() {
    setBackground( Color.YELLOW );
    aantalVrouwen = 0;
    aantalMannen = 0;
    totaal = 0;
    vrouwKnop = new JButton( "V" );
    vrouwKnop.addActionListener( new VrouwKnopHandler() );

    manKnop = new JButton( "M" );
    manKnop.addActionListener( new ManKnopHandler() );

    totaalKnop = new JButton( "Totaal" );
    totaalKnop.addActionListener( new TotaalKnopHandler() );

    add( vrouwKnop );
    add( manKnop );
    add( totaalKnop );
  }

  public void paintComponent( Graphics g ) {
    super.paintComponent( g );
    // Zet aantal vrouwen en mannen op het scherm
    g.drawString( "vrouwen: " + aantalVrouwen, 10, 100 );
    g.drawString( "mannen: " + aantalMannen, 200, 100 );
    
    g.drawString( "totaal: " + totaal, 10, 130 );
  }
  
  class VrouwKnopHandler implements ActionListener {
    public void actionPerformed( ActionEvent e ) {
      aantalVrouwen++;
      repaint();
    }
  }
  
  class ManKnopHandler implements ActionListener {
    public void actionPerformed( ActionEvent e ) {
      aantalMannen++;
      repaint();
    }
  }

  class TotaalKnopHandler implements ActionListener {
    public void actionPerformed( ActionEvent e ) {
      totaal = aantalVrouwen + aantalMannen;
      repaint();
    }
  }

}
