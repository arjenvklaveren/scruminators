// Oefening 0301
import javax.swing.*;
import java.awt.*;  // Nodig voor Graphics
   
// Opstartklasse
public class Oefening0301 extends JFrame {
  public static void main( String args[] ) {
    JFrame frame = new Oefening0301();
    frame.setSize( 400, 200 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Oefening 0301" );
    frame.setContentPane( new Paneel() );
    frame.setVisible( true );
  }
}

// Het paneel 
class Paneel extends JPanel {
  private int secondenPerUur;
  private int secondenPerDag;
  private int secondenPerJaar;
  
  public Paneel() {
    secondenPerUur = 60 * 60;
    secondenPerDag = 24 * secondenPerUur;
    secondenPerJaar = 365 * secondenPerDag;
  }
  
  public void paintComponent( Graphics g ) {
    super.paintComponent( g );
    // Zet de waarden op het scherm:
    g.drawString( "seconden per uur = " + secondenPerUur, 40, 40 );
    g.drawString( "seconden per dag = " + secondenPerDag, 40, 60 );
    g.drawString( "seconden per jaar = " + secondenPerJaar, 40, 80 );
  }
}
