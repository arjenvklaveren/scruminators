// Oefening 0304
import javax.swing.*;
import java.awt.*;  // Nodig voor Graphics
   
// Opstartklasse  
public class Oefening0304 extends JFrame {
  public static void main( String args[] ) {
    JFrame frame = new Oefening0304();
    frame.setSize( 400, 200 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Oefening 0304" );
    frame.setContentPane( new Paneel() );
    frame.setVisible( true );
  }
}

// Het paneel 
class Paneel extends JPanel {
  private int leeftijdInSeconden;
  private int aantalUur;
  private int aantalMinuten;
  private int aantalWeken, aantalDagen, secondenPerUur;
  
  public Paneel() {
    secondenPerUur = 60 * 60;
    leeftijdInSeconden = 5454532;
    aantalUur= leeftijdInSeconden / secondenPerUur;
    aantalMinuten = leeftijdInSeconden / 60;
    int secondenPerDag = secondenPerUur * 24;
    aantalDagen = leeftijdInSeconden / secondenPerDag;    
    aantalWeken = aantalDagen / 7;
  }
  
  public void paintComponent( Graphics g ) {
    super.paintComponent( g );
    g.drawString( "leeftijdInSeconden = " + leeftijdInSeconden, 40, 40 );
    g.drawString( "aantalMinuten = " + aantalMinuten, 40, 60 );
    g.drawString( "aantalUur = " + aantalUur, 40, 80 );
    g.drawString( "aantalDagen = " + aantalDagen, 40, 100 );
    g.drawString( "aantalWeken = " + aantalWeken, 40, 120 );
    
  }
}
