// Oefening 0315
// Dobbelsteen
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
   
public class Oefening0315 extends JFrame {
  public static void main( String args[] ) {
    JFrame frame = new Oefening0315();
    frame.setSize( 230, 240 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Dobbelsteen" );
    frame.setContentPane( new Dobbelsteenpaneel() );
    frame.setVisible( true );
  }
}


class Dobbelsteenpaneel extends JPanel {
  public Dobbelsteenpaneel() {
   // setBackground( Color.YELLOW );
  }

  public void paintComponent( Graphics g ) {
    super.paintComponent( g );
    // Teken de dobbelsteen
    g.setColor( Color.WHITE );
    g.fillRoundRect( 55, 55, 100, 100, 25, 25 );
    g.setColor( Color.BLACK );
    g.drawRoundRect( 55, 55, 100, 100, 25, 25 );
    
    // Teken de stippen
    g.fillOval( 70, 70, 15, 15 );
    g.fillOval( 100, 100, 15, 15 );
    g.fillOval( 130, 130, 15, 15 );
  }
}
