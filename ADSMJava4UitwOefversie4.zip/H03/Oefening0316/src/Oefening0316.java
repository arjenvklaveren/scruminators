// Oefening 0316
// Huishoudbeurs
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
   
public class Oefening0316 extends JFrame {
  public static void main( String args[] ) {
    JFrame frame = new Oefening0316();
    frame.setSize( 400, 200 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Telling huishoudbeurs" );
    frame.setContentPane( new Huishoudbeurspaneel() );
    frame.setVisible( true );
  }
}


class Huishoudbeurspaneel extends JPanel {
  private JButton vrouwKnop, manKnop;
  private int aantalVrouwen, aantalMannen;
  	
  public Huishoudbeurspaneel() {
    setBackground( Color.YELLOW );
    aantalVrouwen = 0;
    aantalMannen = 0;
    vrouwKnop = new JButton( "V" );
    vrouwKnop.addActionListener( new VrouwKnopHandler() );

    manKnop = new JButton( "M" );
    manKnop.addActionListener( new ManKnopHandler() );

    add( vrouwKnop );
    add( manKnop );
  }

  public void paintComponent( Graphics g ) {
    super.paintComponent( g );
    // Zet aantal vrouwen op het scherm
    g.drawString( "vrouwen: " + aantalVrouwen, 10, 100 );
    g.drawString( "mannen: " + aantalMannen, 200, 100 );
  }
  
  class VrouwKnopHandler implements ActionListener {
    public void actionPerformed( ActionEvent e ) {
      aantalVrouwen++;
      repaint();
    }
  }
  
  class ManKnopHandler implements ActionListener {
    public void actionPerformed( ActionEvent e ) {
      aantalMannen++;
      repaint();
    }
  }
}
