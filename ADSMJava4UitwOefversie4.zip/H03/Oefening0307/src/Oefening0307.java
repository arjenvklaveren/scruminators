// Oefening 0307
import javax.swing.*;
import java.awt.*;  // Nodig voor Graphics
   
// Opstartklasse  
public class Oefening0307 extends JFrame {
  public static void main( String args[] ) {
    JFrame frame = new Oefening0307();
    frame.setSize( 400, 300 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Oefening 0307" );
    frame.setContentPane( new Paneel() );
    frame.setVisible( true );
  }
}

// Het paneel 
class Paneel extends JPanel {

  public Paneel() {
  	// hier hoeft niets te gebeuren
  }
  
  public void paintComponent( Graphics g ) {
    super.paintComponent( g );
    // teken de vlaggenmast
    g.drawLine( 100, 250, 100, 50 );
    // teken de driekleur
    g.setColor( Color.RED );
    g.fillRect( 100, 50, 100, 20 );
    g.setColor( Color.GREEN );
    g.fillRect( 100, 70, 100, 20 );
    g.setColor( Color.BLUE );
    g.fillRect( 100, 90, 100, 20 );
  }
}
