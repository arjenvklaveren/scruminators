// Oefening 0310
// Optelling, vermenigvuldigings, verschil, quotient en rest.
// Schoonmaken van tekstvakken
// Invoer van gehele getallen in een tekstvak
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class Oefening0310 extends JFrame {
  public static void main( String args[] ) {
    JFrame frame = new Oefening0310();
    frame.setSize( 280, 200 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Oefening 0310" );
    frame.setContentPane( new Optelpaneel() );
    frame.setVisible( true );
  }
}

// Paneel met drie tekstvakken
class Optelpaneel extends JPanel {
  JTextField invoervak1, invoervak2, resultaatVak;
  JButton plusKnop, maalKnop, verschilKnop, quotientKnop, restKnop, schoonKnop;
  
  public Optelpaneel() {
    invoervak1 = new JTextField( 10 );
    invoervak2 = new JTextField( 10 );
    resultaatVak = new JTextField( 10 );

    plusKnop = new JButton( "+" );
    maalKnop = new JButton( "x" );
    verschilKnop = new JButton( "-" );
    quotientKnop = new JButton( "/" );
    restKnop = new JButton( "%" );
    schoonKnop = new JButton( "C" );

    plusKnop.addActionListener( new PlusKnopHandler() );
    maalKnop.addActionListener( new MaalKnopHandler() );
    verschilKnop.addActionListener( new VerschilKnopHandler() );
    quotientKnop.addActionListener( new QuotientKnopHandler() );
    restKnop.addActionListener( new RestKnopHandler() );
    schoonKnop.addActionListener( new SchoonKnopHandler() );

    add( invoervak1 );
    add( invoervak2 );
    add( plusKnop );
    add( maalKnop );
    add( verschilKnop );
    add( quotientKnop );
    add( restKnop );
    add( schoonKnop );

    add( resultaatVak );
  }

  // Inwendige klassen
  class PlusKnopHandler implements ActionListener {
    public void actionPerformed( ActionEvent e ) {
      String invoerstring1 = invoervak1.getText();
      int getal1 = Integer.parseInt( invoerstring1 );

      String invoerstring2 = invoervak2.getText();
      int getal2 = Integer.parseInt( invoerstring2 );
      int resultaat = getal1 + getal2;
      resultaatVak.setText( "" + resultaat );
    }
  }  

  class MaalKnopHandler implements ActionListener {
    public void actionPerformed( ActionEvent e ) {
      String invoerstring1 = invoervak1.getText();
      int getal1 = Integer.parseInt( invoerstring1 );

      String invoerstring2 = invoervak2.getText();
      int getal2 = Integer.parseInt( invoerstring2 );
      int resultaat = getal1 * getal2;
      resultaatVak.setText( "" + resultaat );
    }
  }  

  class VerschilKnopHandler implements ActionListener {
    public void actionPerformed( ActionEvent e ) {
      String invoerstring1 = invoervak1.getText();
      int getal1 = Integer.parseInt( invoerstring1 );

      String invoerstring2 = invoervak2.getText();
      int getal2 = Integer.parseInt( invoerstring2 );
      int resultaat = getal1 - getal2;
      resultaatVak.setText( "" + resultaat );
    }
  }  

  class QuotientKnopHandler implements ActionListener {
    public void actionPerformed( ActionEvent e ) {
      String invoerstring1 = invoervak1.getText();
      int getal1 = Integer.parseInt( invoerstring1 );

      String invoerstring2 = invoervak2.getText();
      int getal2 = Integer.parseInt( invoerstring2 );
      double resultaat = (double) getal1 / getal2;
      resultaatVak.setText( "" + resultaat );
    }
  }  

  class RestKnopHandler implements ActionListener {
    public void actionPerformed( ActionEvent e ) {
      String invoerstring1 = invoervak1.getText();
      int getal1 = Integer.parseInt( invoerstring1 );

      String invoerstring2 = invoervak2.getText();
      int getal2 = Integer.parseInt( invoerstring2 );
      int resultaat = getal1 % getal2;
      resultaatVak.setText( "" + resultaat );
    }
  }  

  class SchoonKnopHandler implements ActionListener {
    public void actionPerformed( ActionEvent e ) {
      invoervak1.setText( "" );
      invoervak2.setText( "" );
      resultaatVak.setText( ""  );
    }
  }  
}
