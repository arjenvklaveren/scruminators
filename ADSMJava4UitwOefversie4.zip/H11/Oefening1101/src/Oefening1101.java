// Oefening 1101
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;  
   
public class Oefening1101 extends JFrame {
  public static void main( String args[] ) {
    JFrame frame = new Oefening1101();
    frame.setSize( 450, 300 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Oefening 1101" );
    frame.setContentPane( new Display() );
    frame.setVisible( true );
  }
}

// Het paneel 
class Display extends JPanel {
  private JTextField invoerVak1, invoerVak2, uitvoerVak;
  private JLabel invoerLabel1, invoerLabel2, uitvoerLabel;
  private JButton knop;
  
  public Display() {
    // Schakel lay-outmanager uit
    setLayout( null ); 
    
    // Maak de tekstvakken
    invoerVak1 = new JTextField( 10 );
    invoerVak1.setHorizontalAlignment( JTextField.RIGHT );

    invoerVak2 = new JTextField( 10 );
    invoerVak2.setHorizontalAlignment( JTextField.RIGHT );

    uitvoerVak = new JTextField( 10 );
    uitvoerVak.setHorizontalAlignment( JTextField.RIGHT );
    uitvoerVak.setBackground( Color.YELLOW );
    // Schakel wijzigen van inhoud tekstvak door gebruiker uit
    uitvoerVak.setEditable( false );
    
    // Maak de labels
    invoerLabel1 = new JLabel( "Eerste getal" );
    invoerLabel2 = new JLabel( "Tweede getal" );

    uitvoerLabel = new JLabel( "Resultaat" );
    
    // Maak de knop
    knop = new JButton( "Deel" );
    knop.addActionListener( new KnopHandler() );
    
    // Bepaal van alle componenten de plaats en afmeting
    invoerLabel1.setBounds( 80, 50, 120, 20 );
    invoerVak1.setBounds( 200, 50, 90, 20 );
 
    invoerLabel2.setBounds( 80, 80, 120, 20 );
    invoerVak2.setBounds( 200, 80, 90, 20 );
    
    knop.setBounds( 200, 110, 90, 20 );

    uitvoerLabel.setBounds( 80, 140, 120, 20 );
    uitvoerVak.setBounds( 200, 140, 90, 20 );
    
    // Voeg de componenten toe aan het paneel
    add( invoerLabel1);
    add( invoerVak1 );

    add( invoerLabel2);
    add( invoerVak2 );

    add( knop );
 
    add( uitvoerLabel );
    add( uitvoerVak );
    
    invoerVak2.addActionListener( new KnopHandler() );
  }

  class KnopHandler implements ActionListener {
    public void actionPerformed( ActionEvent e ) {
      String invoer1 = invoerVak1.getText();
      String invoer2 = invoerVak2.getText();
      int getal1, getal2, resultaat;
      
      try {
        getal1 = Integer.parseInt( invoer1 );
        getal2 = Integer.parseInt( invoer2 );

        resultaat = getal1 / getal2;
        // Zet op scherm
        uitvoerVak.setText( "" + resultaat );
      }
      catch( ArithmeticException aex ) {
        uitvoerVak.setText( "Delen door 0" );
      }
      catch( NumberFormatException nfex ) {
        uitvoerVak.setText( "Ongeldig getal" );
      }
    }
  }
}
