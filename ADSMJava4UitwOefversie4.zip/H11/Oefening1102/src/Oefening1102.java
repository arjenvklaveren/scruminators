// Oefening 1102
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;  
   
public class Oefening1102 extends JFrame {
  public static void main( String args[] ) {
    JFrame frame = new Oefening1102();
    frame.setSize( 450, 200 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Oefening 1102" );
    frame.setContentPane( new Display() );
    frame.setVisible( true );
  }
}

// Het paneel 
class Display extends JPanel {
  private JTextField invoerVak, uitvoerVak;
  private JLabel invoerLabel, uitvoerLabel;
  
  public Display() {
    // Schakel lay-outmanager uit
    setLayout( null ); 
    
    // Maak de tekstvakken
    invoerVak = new JTextField( 10 );
    invoerVak.setHorizontalAlignment( JTextField.RIGHT );
    invoerVak.addActionListener( new VakHandler() );

    uitvoerVak = new JTextField( 10 );
    uitvoerVak.setHorizontalAlignment( JTextField.RIGHT );
    uitvoerVak.setBackground( Color.YELLOW );
    // Schakel wijzigen van inhoud tekstvak door gebruiker uit
    uitvoerVak.setEditable( false );
    
    // Maak de labels
    invoerLabel = new JLabel( "Voer geheel getal tussen 1 en 10 in" );

    uitvoerLabel = new JLabel( "Resultaat" );
    
    // Bepaal van alle componenten de plaats en afmeting
    invoerLabel.setBounds( 80, 50, 200, 20 );
    invoerVak.setBounds( 300, 50, 90, 20 );
 
    uitvoerLabel.setBounds( 80, 90, 200, 20 );
    uitvoerVak.setBounds( 300, 90, 90, 20 );
    
    // Voeg de componenten toe aan het paneel
    add( invoerLabel);
    add( invoerVak );

    add( uitvoerLabel );
    add( uitvoerVak );
    
  }

  class VakHandler implements ActionListener {
    public void actionPerformed( ActionEvent e ) {
      String invoer = invoerVak.getText();
      int getal;
      
      try {
        getal = Integer.parseInt( invoer );
        
        if( getal < 1 || getal > 10 )
          throw new NumberFormatException();
        uitvoerVak.setText( "OK" );
      }
      catch( NumberFormatException nfex ) {
        uitvoerVak.setText( "Ongeldig getal" );
      }
    }
  }
}
