// Oefening 0211
import javax.swing.*;
import java.awt.event.*;

public class Oefening0211 extends JFrame
{
  public static void main( String args[] )
  {
    JFrame frame = new Oefening0211();
    frame.setSize( 300, 200 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Oefening 0211" );
    JPanel paneel = new Paneel();
    frame.setContentPane( paneel );
    frame.setVisible( true );
  }
}

class Paneel extends JPanel
{
  private JButton knop1, knop2, knop3;
  private JTextField tekstvak;

  public Paneel()
  {
    knop1 = new JButton( "Tekst 1" );
    knop2 = new JButton( "Tekst 2" );
    knop3 = new JButton( "Tekst 3" );
    tekstvak = new JTextField( 10 );
    
    knop1.addActionListener( new Knop1Handler() );
    knop2.addActionListener( new Knop2Handler() );
    knop3.addActionListener( new Knop3Handler() );
    
    add( knop1 );
    add( knop2 );
    add( knop3 );
    add( tekstvak );
  }
  
    // Inwendige klassen
  class Knop1Handler implements ActionListener {
    public void actionPerformed( ActionEvent e ) {
      tekstvak.setText( "Een" );
    }
  }
  
  class Knop2Handler implements ActionListener {
    public void actionPerformed( ActionEvent e ) {
      tekstvak.setText( "Twee" );
    }
  }  

  class Knop3Handler implements ActionListener {
    public void actionPerformed( ActionEvent e ) {
      tekstvak.setText( "Drie" );
    }
  }  
 
}
