// Oefening 0210
import javax.swing.*;
import java.awt.event.*;

public class Oefening0210 extends JFrame
{
  public static void main( String args[] )
  {
    JFrame frame = new Oefening0210();
    frame.setSize( 300, 200 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Oefening 0210" );
    JPanel paneel = new Paneel();
    frame.setContentPane( paneel );
    frame.setVisible( true );
  }
}

class Paneel extends JPanel
{
  private JButton knopVoor, knopAchter;
  private JTextField tekstvakVoor, tekstvakAchter;

  public Paneel()
  {
    knopVoor = new JButton( "Voornaam" );
    knopAchter = new JButton( "Achternaam" );
    tekstvakVoor = new JTextField( 10 );
    tekstvakAchter = new JTextField( 10 );
    
    knopVoor.addActionListener( new KnopVoorHandler() );
    knopAchter.addActionListener( new KnopAchterHandler() );
    
    add( knopVoor );
    add( tekstvakVoor );
    add( knopAchter );
    add( tekstvakAchter );
  }
  
    // Inwendige klasse
  class KnopVoorHandler implements ActionListener {
    public void actionPerformed( ActionEvent e ) {
      tekstvakVoor.setText( "Mijn voornaam" );
    }
  }
  
  // Nog een inwendige klasse
  class KnopAchterHandler implements ActionListener {
    public void actionPerformed( ActionEvent e ) {
      tekstvakAchter.setText( "Mijn achternaam" );
    }
  }  
}
