import java.awt.*;

public class Spaakwiel extends AbstractWiel implements Onderdeel {

  public Spaakwiel( Color kleur, int links, int onder, int diameter ) {
    super( kleur, links, onder, diameter );
  }

  @Override
  public void teken( Graphics g ) {
    g.setColor( kleur ) ;
    g.fillOval( links, onder-diameter, diameter, diameter );
    g.setColor( Color.BLACK );
    g.drawOval( links, onder-diameter, diameter, diameter );
    
    xM = links + r;
    
    int sina = (int) ( r * Math.sin( alfa ) );
    int cosa = (int) ( r * Math.cos( alfa ) );
    
    g.drawLine(  xM - cosa, yM + sina, xM + cosa, yM - sina );
    g.drawLine( xM - sina, yM - cosa, xM + sina, yM + cosa );
  }
}
  