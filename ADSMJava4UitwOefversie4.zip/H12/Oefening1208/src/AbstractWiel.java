import java.awt.*;

public abstract class AbstractWiel implements Onderdeel {
  protected int links, onder, diameter, r;    // links, onder, diameter en straal van de cirkel  
  protected Color kleur;
  protected int xM, yM;    // Middelpunt van cirkel
  protected double alfa;   // Hoek waaronder het wiel bij aanvang staat

  public AbstractWiel( Color kleur, int links, int onder, int diameter ) {
    this.kleur = kleur;
    this.links = links;
    this.onder = onder;
    this.diameter = diameter;
    this.r = diameter / 2;
    yM = onder - r;
    alfa = Math.random() * 2 * Math.PI;
  }

  public abstract void teken( Graphics g );
  
  public void naarRechts() {
    links++;
    alfa -= 1.0 / r;
  }
}
