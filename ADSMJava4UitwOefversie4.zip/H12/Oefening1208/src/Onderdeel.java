import java.awt.*;

public interface Onderdeel {
  public void teken( Graphics g ); 
  public void naarRechts();
}
  