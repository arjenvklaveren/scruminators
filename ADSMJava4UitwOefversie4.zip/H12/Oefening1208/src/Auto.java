import java.awt.*;
import java.util.*;

public class Auto {
  private ArrayList<Onderdeel> onderdelenlijst;

  public Auto( int links, int onder, int breedte, int hoogte ) {
    onderdelenlijst = new ArrayList<Onderdeel>();
    int wielgrootte = 20;
    int carosOnder = onder - wielgrootte/2;


    // De carosserie
    onderdelenlijst.add( new Rechthoek( Color.blue, links, onder-10, breedte,hoogte ) );

    // De cabine
    onderdelenlijst.add( new Rechthoek( Color.cyan, links, onder-10-hoogte, 4*breedte/5, 4*hoogte/5 ) );

    // Het achterwiel
    onderdelenlijst.add( new Spaakwiel( Color.yellow, links+5, onder, (int) ( wielgrootte * 1.2 ) ) );

    // Het voorwiel
    onderdelenlijst.add( new Wiel( Color.yellow, links+breedte-30, onder, wielgrootte ) );
  }

  public void teken( Graphics g ) {
    for( Onderdeel part : onderdelenlijst ) {
      part.teken( g );
    }
  }
  
  public void naarRechts() {
    for( Onderdeel part : onderdelenlijst ) {
      part.naarRechts();
    }
  }
}
  