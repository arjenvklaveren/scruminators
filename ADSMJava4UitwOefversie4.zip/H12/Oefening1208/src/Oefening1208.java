// Oefening 1208  Auto
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Oefening1208 extends JFrame {
  public static void main( String args[] ) {
    JFrame frame = new Oefening1208();
    frame.setSize( 1920, 200 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Oefening 1208  Auto" );
    frame.setContentPane( new Autopaneel() );
    frame.setVisible( true );
  }
}

class Autopaneel extends JPanel {
  private Timer timer;
  private JButton startknop, stopknop;
  private Auto auto;
    
  public Autopaneel() {
    timer = new Timer( 10, new TimerHandler() );
    
    startknop = new JButton( "Start" );
    stopknop =  new JButton( "Stop" );
    add( startknop );
    add( stopknop );       

    KnopHandler kh = new KnopHandler();
    startknop.addActionListener( kh );
    stopknop.addActionListener( kh );
    
    auto = new Auto( 50, 100, 100, 40 );
  }

  public void paintComponent( Graphics g ) {
    super.paintComponent( g );
    auto.teken( g );
  }

  class TimerHandler implements ActionListener{
    public void actionPerformed( ActionEvent e ) {
      auto.naarRechts();
      repaint();
    }
  }
  
  class KnopHandler implements ActionListener {
    public void actionPerformed( ActionEvent e ) {
      if( e.getSource() == startknop ) 
        timer.start();
      if( e.getSource() == stopknop ) 
        timer.stop();
    }
  }
}
