import java.awt.*;

public class Wiel extends AbstractWiel implements Onderdeel {

  public Wiel( Color kleur, int links, int onder, int diameter ) {
    super( kleur, links, onder, diameter );
  }

  @Override
  public void teken( Graphics g ) {
    g.setColor( kleur ) ;
    g.fillOval( links, onder-diameter, diameter, diameter );
    g.setColor( Color.BLACK );
    g.drawOval( links, onder-diameter, diameter, diameter );
    
    xM = links + diameter / 2;
    int xMS = (int) ( xM + diameter * Math.cos( alfa ) / 4 );
    int yMS = (int) ( yM - diameter * Math.sin( alfa ) / 4 );
    g.setColor( Color.RED );
    g.fillOval( xMS -5, yMS - 5, 10, 10 );
  }
}
  