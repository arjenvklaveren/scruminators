// Oefening 1202  Stuiterende ballen
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class Oefening1202 extends JFrame {
  public static void main( String args[] ) {
    JFrame frame = new Oefening1202();
    frame.setSize( 400, 280 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Oefening 1202  Stuiterende ballen" );
    frame.setContentPane( new Totaalpaneel() );
    frame.setVisible( true );
  }
}


class Totaalpaneel extends JPanel {
  private ArrayList<Bal> lijst;  

  public Totaalpaneel() {
    lijst = new ArrayList<Bal>();

    setLayout( new BorderLayout() );
    add( new Balpaneel( lijst ), BorderLayout.CENTER );
    add( new Bedieningspaneel( lijst ), BorderLayout.SOUTH );
  }
}


class Balpaneel extends JPanel {
  private javax.swing.Timer timer;
  private int teller;
  private ArrayList<Bal> lijst;  
    
  public Balpaneel( ArrayList<Bal> lijst ) {
    this.lijst = lijst;
    timer = new javax.swing.Timer( 50, new TimerHandler() );    
    timer.start();    
  }
  
  public void paintComponent( Graphics g ) {
    super.paintComponent( g );
    setBackground( Color.WHITE );
    g.translate( 200, 220 );
    g.drawLine( -110, 10, 120, 10 );
    for( Bal b : lijst ) 
      b.stuiter( g ); 
  }

  class TimerHandler implements ActionListener{
    public void actionPerformed( ActionEvent e ) {
      repaint();
    }
  }
}

class Bedieningspaneel extends JPanel {
  private JButton knop;
  private int rood, groen, blauw;
  private ArrayList<Bal> lijst;
  
  public Bedieningspaneel( ArrayList<Bal> lijst ) {
    this.lijst = lijst;
    knop = new JButton( "Nog een bal" );       
    knop.addActionListener( new KnopHandler() );
    add( knop );
  }
  
  class KnopHandler implements ActionListener{
    public void actionPerformed( ActionEvent e ) {
      // Maak een nieuwe kleur
      rood += 20;
      groen += 50;
      blauw += 100;
      Color kleur = new Color( rood %= 256, groen %= 256, blauw %= 256 );

      // Maak een nieuwe bal en voeg hem aan de lijst toe 
      lijst.add( new Bal( 100, 0, 10, kleur ) );
    }
  }
}
