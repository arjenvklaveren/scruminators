// Oefening 1201  Twee stuiterende ballen
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Oefening1201 extends JFrame {
  public static void main( String args[] ) {
    JFrame frame = new Oefening1201();
    frame.setSize( 400, 280 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Oefening 1201  Stuiterende bal" );
    frame.setContentPane( new Balpaneel() );
    frame.setVisible( true );
  }
}

class Balpaneel extends JPanel {
  private Timer timer;
  private int teller;
  private Bal bal1, bal2;  

  public Balpaneel() {
    bal1 = new Bal( -100, 0, 10, Color.RED );
    bal2 = new Bal( 100, 0, 10, Color.BLUE );
      
    timer = new Timer( 10, new TimerHandler() );    
    timer.start();    
  }
  
  public void paintComponent( Graphics g ) {
    super.paintComponent( g );
    setBackground( Color.WHITE );
    g.translate( 200, 220 );
    g.drawLine( -110, 10, 120, 10 );
    bal1.stuiter( g ); 
    bal2.stuiter( g ); 
  }

  class TimerHandler implements ActionListener{
    public void actionPerformed( ActionEvent e ) {
      repaint();
    }
  }
}
