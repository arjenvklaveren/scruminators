import java.awt.*;

public class Happer {
  // Attributen
  private int links;              // positie van happer
  private int boven;
  private int breedte = 60;       // grootte van happer
  private int hoogte = 60;
  private Color kleur;            // kleur van happer
  
  // Constructor
  public Happer( int links, int boven, Color kleur ) {
    this.links = links;
    this.boven = boven;
    this.kleur = kleur;
  }
  
  void naarRechts() {
    this.links++;
  }
  
  void tekenOpen( Graphics g ) {
    g.setColor( kleur );
    g.fillArc( links, boven, breedte, hoogte, 20, 300 );
    g.setColor( Color.yellow );
    g.fillOval( links + breedte / 2, boven + hoogte / 4, 5, 5 );
  }
  
  void tekenDicht( Graphics g ) {
    g.setColor( kleur );
    g.fillArc( links, boven, breedte, hoogte, 5, 350 );
    g.setColor( Color.yellow );
    g.fillOval( links + breedte / 2, boven + hoogte / 4, 5, 5 );
  }
  
/*  void wis( Graphics g ) {
    g.setColor( achtergrondkleur );
    g.fillOval( this.links, this.boven,
      this.breedte+1, this.hoogte+1 );
  }
*/
}

