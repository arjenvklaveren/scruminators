// Oefening 1207  Pacman
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Oefening1207 extends JFrame {
  public static void main( String args[] ) {
    JFrame frame = new Oefening1207();
    frame.setSize( 400, 280 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Oefening 1207  Pacman" );
    frame.setContentPane( new Pacmanpaneel() );
    frame.setVisible( true );
  }
}

class Pacmanpaneel extends JPanel {
  private Timer timer;
  private JButton startknop, stopknop;
  private int frameteller;     // telt het aantal frames, afhankelijk van het aantal heeft happer mond open of dicht
  private Happer happer;
    
  public Pacmanpaneel() {
    timer = new Timer( 10, new TimerHandler() );
    
    startknop = new JButton( "Start" );
    stopknop =  new JButton( "Stop" );
    add( startknop );
    add( stopknop );       

    KnopHandler kh = new KnopHandler();
    startknop.addActionListener( kh );
    stopknop.addActionListener( kh );
    
    happer = new Happer( -50, 100, Color.RED );
    setBackground( Color.BLACK );
  }

  public void paintComponent( Graphics g ) {
    super.paintComponent( g );
    if( frameteller / 10 % 2 == 0 )            // 10 frames met mond dicht
      happer.tekenDicht( g );
    else 
      happer.tekenOpen( g );                   // 10 frames met mond open
  }

  class TimerHandler implements ActionListener{
    public void actionPerformed( ActionEvent e ) {
      happer.naarRechts();
      frameteller++;
      repaint();
    }
  }
  
  class KnopHandler implements ActionListener {
    public void actionPerformed( ActionEvent e ) {
      if( e.getSource() == startknop ) 
        timer.start();
      if( e.getSource() == stopknop ) 
        timer.stop();
    }
  }
}
