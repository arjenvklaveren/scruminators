// Oefening 1206  Lichtkrant
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Oefening1206 extends JFrame {
  public static void main( String args[] ) {
    JFrame frame = new Oefening1206();
    frame.setSize( 400, 280 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Oefening 1206  Lichtkrant" );
    frame.setContentPane( new Lichtkrantpaneel() );
    frame.setVisible( true );
  }
}

class Lichtkrantpaneel extends JPanel {
  private String tekst;
  private int xPos, xMax;
  private Timer timer;
  private JButton startknop, stopknop;
  
  public Lichtkrantpaneel() {
    tekst = "Lees hier de nieuwe lichtkrant!";
    xPos = xMax = 410;
    timer = new Timer( 10, new TimerHandler() );
    
    startknop = new JButton( "Start" );
    stopknop =  new JButton( "Stop" );
    
    add( startknop );
    add( stopknop );       

    KnopHandler kh = new KnopHandler();
    startknop.addActionListener( kh );
    stopknop.addActionListener( kh );
  }

  public void paintComponent( Graphics g ) {
    super.paintComponent( g );
    g.setColor( Color.BLUE );
    g.setFont( new Font( "SansSerif", Font.BOLD + Font.ITALIC, 14 ) );
    g.drawString( tekst, xPos, 80 );
  }

  class TimerHandler implements ActionListener{
    public void actionPerformed( ActionEvent e ) {
      xPos--;
      if( xPos < -220 )
        xPos = xMax;
      repaint();
    }
  }
  
  class KnopHandler implements ActionListener {
    public void actionPerformed( ActionEvent e ) {
      if( e.getSource() == startknop ) 
        timer.start();
      if( e.getSource() == stopknop ) 
        timer.stop();
    }
  }
}
