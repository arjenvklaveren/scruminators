import java.awt.*;

public class Biljart {
  public int links, boven, rechts, onder;
  
  Biljart( int links, int rechts, int onder, int boven ) {
    this.links = links;
    this.rechts = rechts;
    this.onder = onder;
    this.boven = boven;
  }
  
  void teken( Graphics g ) {
    int breedte = rechts - links, hoogte = onder - boven;
    g.setColor( Color.black );
    g.drawRect( links, boven, breedte, hoogte );
    g.setColor( Color.green );
    g.fillRect( links + 1, boven + 1, breedte - 1, hoogte - 1 );
  }
  
  public int getLinks() {
    return links;
  }

  public int getRechts() {
    return rechts;
  }

  public int getOnder() {
    return onder;
  }

  public int getBoven() {
    return boven;
  }
}
