import java.awt.*;

public class Bal {
  private int grootte;   // diameter van de bal
  private int x, y;      // de positie van de bal
  private int dx = 3, dy = 2;  // grootte van de verplaatsing in x resp y-richting
  private Biljart biljart;
  private Color kleur;   // balkleur
  
  public Bal( Color kleur, int grootte, Biljart biljart ) {
    this.kleur = kleur;
    this.grootte = grootte;
    this.biljart = biljart;
    x = biljart.getLinks() + 1;
    y = biljart.getBoven() + 1;
  }
  
  public void teken( Graphics g ) {
    g.setColor( kleur );
    g.fillOval( x, y, grootte, grootte );
  }
  
  public void verplaats() {
    // Verander indien nodig van richting
    if( x + dx <= biljart.getLinks() ||
      x + dx + grootte >= biljart.getRechts() ) dx = -dx;
    
    if( y + dy <= biljart.getBoven() ||
      y + dy + grootte >= biljart.getOnder() ) dy = -dy;
    
    // veander de positie van de bal 
    x += dx;  y += dy;
  }
}
  