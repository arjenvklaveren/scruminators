// Oefening 1204  Biljartbal
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class Oefening1204 extends JFrame {
  public static void main( String args[] ) {
    JFrame frame = new Oefening1204();
    frame.setSize( 400, 280 );
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setTitle( "Oefening 1204  Biljartbal" );
    frame.setContentPane( new Biljartpaneel() );
    frame.setVisible( true );
  }
}

class Biljartpaneel extends JPanel {
  private javax.swing.Timer timer;
  private Biljart biljart;
  private ArrayList<Bal> ballijst;
  private ArrayList<Color> kleurlijst;
  private JButton knop;
  private int balnr;
  
  public Biljartpaneel() {
    biljart = new Biljart( 50, 320, 200, 50 );
      
    ballijst = new ArrayList<Bal>();
    kleurlijst = new ArrayList<Color>();
    
    kleurlijst.add( Color.RED );
    kleurlijst.add( Color.BLUE );
    kleurlijst.add( Color.BLACK );
    kleurlijst.add( Color.YELLOW );
    kleurlijst.add( Color.MAGENTA );
    kleurlijst.add( Color.WHITE );  
    
    knop = new JButton( "Nieuwe bal" );
    knop.addActionListener( new KnopHandler() );         
    add( knop );
    
    timer = new javax.swing.Timer( 20, new TimerHandler() );    
    timer.start();    
  }
  
  public void paintComponent( Graphics g ) {
    super.paintComponent( g );
    biljart.teken( g );
    for( Bal b : ballijst )
      b.teken( g ); 
  }

  class TimerHandler implements ActionListener{
    public void actionPerformed( ActionEvent e ) {
      for( Bal b : ballijst ) 
        b.verplaats();
      repaint();
    }
  }
  
  class KnopHandler implements ActionListener {
    public void actionPerformed( ActionEvent e ) {
      ballijst.add( new Bal( kleurlijst.get( balnr % kleurlijst.size() ) , 10, biljart ) );
      balnr++;
    }  
  }
}
