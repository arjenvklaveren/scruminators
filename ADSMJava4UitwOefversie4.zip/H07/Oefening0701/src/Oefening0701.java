// Oefening 0701
public class Oefening0701 {
  public static void main( String[] args ) {
  	Persoon vriendin = new Persoon( "Jeannette",  new Datum( 29, 7, 1994 ) );
  	System.out.println( vriendin );
  }
}
